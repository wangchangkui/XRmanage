package XR.main;


import XR.Model.Connect.Connect;
import XR.Model.Manager;
import XR.Model.UserModel;
import XR.ui.MainFrame;

import javax.swing.*;
import java.sql.ResultSet;
import java.sql.SQLException;

public class run {
    public static void main(String[] args) throws SQLException {
        //设置界面
        String plaf="com.sun.java.swing.plaf.windows.WindowsLookAndFeel";

        //异常处理
        try {
            UIManager.setLookAndFeel(plaf);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }

        /*
        * setResizable(false) 静止最大化
        * setLocationRelativeTo(null) 居中显示
        * setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) 窗口可关闭
        * setVisible(true) 窗口可见
        * */
        MainFrame mf=new MainFrame();
        mf.setResizable(false);
        mf.setLocationRelativeTo(null);
        mf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mf.setVisible(true);


        /*
        * 数据库连接测试
        * */
        //测试数据库 已经连通
//        Connect connect=new Connect();
//        connect.SQlTest();


        /*
        * UserModel 测试
        * */
        //UserModel userModel=new UserModel();

        /*
        * manager 测试
        * */
        //Manager manager=new Manager();


    }

}
