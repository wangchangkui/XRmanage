package XR.ui;

import XR.Model.Complay;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class SeeComplay extends JPanel {
    public SeeComplay() throws SQLException {
        //浏览表
        Complay complay=new Complay();
        JPanel seePanel=new JPanel();
        seePanel.setBorder(new TitledBorder("数据内容"));

        JTable tables=new JTable();
        DefaultTableModel tableModel=(DefaultTableModel) tables.getModel();

        tableModel.addColumn("供货商ID");
        tableModel.addColumn("供货单位名称");
        tableModel.addColumn("供货联系人");
        tableModel.addColumn("供货联系电话");
        tableModel.addColumn("供货单位地址");
        tableModel.addColumn("备注");
        tableModel.addColumn("供货简码");
        tableModel.addColumn("供货编码");
        tableModel.addColumn("供货商销售范围");

        List<Map<String, Object>> list= new ArrayList<>();
        Map<String, Object> map=null;
        list=complay.SelectAllinfo();
        int count=list.size();
        for(int i=0;i<count;i++){
            map=list.get(i);
            Object[] obj = new String[]{map.get("complay_id").toString(), map.get("complay_name").toString(), map.get("complay_peo").toString(), map.get("complay_peo_call").toString(), map.get("complay_address").toString(), map.get("complay_forget").toString(), map.get("complay_code").toString(), map.get("complay_encode").toString(), map.get("complay_sell").toString()};
            tableModel.addRow(obj);
        }

        tables.setShowGrid(true);
        tables.setRowHeight(30);
        tables.setGridColor(new Color(3,169,244));
        tables.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.getTableHeader().setBorder(new EtchedBorder(EtchedBorder.LOWERED));

        //滑动
        tables.setPreferredScrollableViewportSize(new Dimension(10,500));





        GroupLayout groupLayout=new GroupLayout(seePanel);
        GroupLayout.SequentialGroup hg=groupLayout.createSequentialGroup();
        hg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE).addComponent(tables,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vg=groupLayout.createSequentialGroup();

        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables,GroupLayout.DEFAULT_SIZE,600,GroupLayout.PREFERRED_SIZE));

        groupLayout.setHorizontalGroup(hg);
        groupLayout.setVerticalGroup(vg);
        seePanel.setLayout(groupLayout);



        //底部
        JPanel infos=new JPanel();
        JButton button=new JButton("删除");
        JButton editButton=new JButton("保存修改");
        JButton exitButton=new JButton("放弃修改");
        GroupLayout groupLayout2=new GroupLayout(infos);
        GroupLayout.SequentialGroup vgroups=groupLayout2.createSequentialGroup();
        vgroups.addContainerGap(10,30);
        vgroups.addGroup(groupLayout2.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(exitButton,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));

        GroupLayout.SequentialGroup hgroups=groupLayout2.createSequentialGroup();
        hgroups.addContainerGap(1,2);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        hgroups.addContainerGap(10,30);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(exitButton,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        hgroups.addContainerGap(10,30);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setVerticalGroup(vgroups);
        groupLayout2.setHorizontalGroup(hgroups);
        infos.setLayout(groupLayout2);



        //主要界面
        GroupLayout group=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=group.createSequentialGroup();
        hgroup.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE)
                .addComponent(infos,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgropu=group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,600,GroupLayout.PREFERRED_SIZE));
        vgropu.addGroup(group.createParallelGroup().addComponent(infos,GroupLayout.PREFERRED_SIZE,200,GroupLayout.PREFERRED_SIZE));
        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);

        final String[] ID = {""};
        //选中删除行 1.获取选中行，获取选中数据 2.修改保存数据
        tables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x=tables.getSelectedRow();
                int y=tables.getSelectedColumn();
                if(x!=-1&&y!=-1){
                    if(y==0){
                        JOptionPane.showMessageDialog(null,
                                "所选列是不能被修改的",
                                "Info",
                                INFORMATION_MESSAGE);
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                    else{
                        while (y>0){
                            y--;
                        }
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                }
            }
        });


        List<Map<String, String>> changelist=new ArrayList<Map<String, String>>();
        final Map<String, String>[] chagemap = new Map[]{null};
        //检测值被修改
        tableModel.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int i=tables.getSelectedRow();
                int j=tables.getSelectedColumn();
                try {
                    if(i==-1||j==-1){
                        //此处有一个BUG 但是不影响使用
                    }
                    else{
                        tables.updateUI();
                        chagemap[0] =new HashMap<String, String>();
                        chagemap[0].put("complay_id",ID[0]);
                        chagemap[0].put("complay_name",tableModel.getValueAt(i,1).toString());
                        chagemap[0].put("complay_peo",tableModel.getValueAt(i,2).toString());
                        chagemap[0].put("complay_peo_call",tableModel.getValueAt(i,3).toString());
                        chagemap[0].put("complay_address",tableModel.getValueAt(i,4).toString());
                        chagemap[0].put("complay_forget",tableModel.getValueAt(i,5).toString());
                        chagemap[0].put("complay_code",tableModel.getValueAt(i,6).toString());
                        chagemap[0].put("complay_encode",tableModel.getValueAt(i,7).toString());
                        chagemap[0].put("complay_sell",tableModel.getValueAt(i,8).toString());
                        changelist.add(chagemap[0]);
                    }
                }
                catch (Exception es){
                    //这里存在了一个BUG 原因是因为删除表数据的时候，这里会往列表添加数据，然而数据已经被删除了，所以发生了一个错误
                    //经过测试，这不会影响此软件的正常操作
                    //2020-11-26
                }

            }
        });


        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int count=changelist.size();
                int ok=0,counts=0;
                if(count!=0){
                    for (int i=0;i<count;i++){
                        Map<String,String> maps=changelist.get(i);
                        ok =complay.UpdateInfo(maps);
                        if(ok!=0){
                            counts++;
                        }
                    }
                    JOptionPane.showMessageDialog(null,
                            "你一共修改了'"+counts+"'次",
                            "数据库",
                            INFORMATION_MESSAGE);

                    //擦除所有数据
                    changelist.clear();
                }
                else {
                    System.out.println("未执行任何修改");
                }
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JOptionPane.showMessageDialog(null,
                        "取消了修改",
                        "数据库",
                        INFORMATION_MESSAGE);

                //删除所有数据

                int i=0;
                while (i<tableModel.getRowCount()){
                    tableModel.removeRow(i);
                }

                //重新加载数据
                List<Map<String, Object>> list;
                Map<String, Object> map;
                try {
                    list=complay.SelectAllinfo();
                    for(int s=0;s<list.size();s++){
                        map=list.get(s);
                        Object[] obj = new String[]{map.get("complay_id").toString(), map.get("complay_name").toString(), map.get("complay_peo").toString(), map.get("complay_peo_call").toString(), map.get("complay_address").toString(), map.get("complay_forget").toString(), map.get("complay_code").toString(), map.get("complay_encode").toString(), map.get("complay_sell").toString()};
                        tableModel.addRow(obj);
                        changelist.clear();
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                System.out.println(changelist.size());
            }
        });



        //处理一个动态加载数据的问题  解决方法 多线程刷新表中的数据

        new Thread(new Runnable() {
            @Override
            public void run() {

                while (true) {
                    try {
                        int row = tableModel.getRowCount();
                        int count = complay.count();
                        if (row != count) {
                            int i = 0;
                            while (i < tableModel.getRowCount()) {
                                tableModel.removeRow(i);
                            }
                            //重新加载数据
                            List<Map<String, Object>> list;
                            Map<String, Object> map;
                            list = complay.SelectAllinfo();
                            for (int s = 0; s < list.size(); s++) {
                                map = list.get(s);
                                Object[] obj = new String[]{map.get("complay_id").toString(), map.get("complay_name").toString(), map.get("complay_peo").toString(), map.get("complay_peo_call").toString(), map.get("complay_address").toString(), map.get("complay_forget").toString(), map.get("complay_code").toString(), map.get("complay_encode").toString(), map.get("complay_sell").toString()};
                                tableModel.addRow(obj);
                                changelist.clear();
                            }
                        }

                        Thread.sleep(3000);
                    } catch (InterruptedException | SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

    }
}
