package XR.ui;

import XR.Model.Drugs_room;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class MidirproduceRooms extends JPanel {
    public MidirproduceRooms(){

        Drugs_room room=new Drugs_room();
        JPanel panel1=new JPanel();
        panel1.setBorder(new TitledBorder("添加药房信息"));
        JLabel label1=new JLabel("药房名称");
        JLabel label2=new JLabel("药品负责人");
        JLabel label3=new JLabel("负责人电话");
        JLabel label4=new JLabel("药房所属区域");
        JLabel label5=new JLabel("药房地址");
        JLabel label6=new JLabel("药房简码");
        JLabel label7=new JLabel("地区编码");
        JLabel label8=new JLabel("药房经营区域");

        JTextField text1=new JTextField();
        JTextField text2=new JTextField();
        JTextField text3=new JTextField();
        JTextField text4=new JTextField();
        JTextField text5=new JTextField();
        JTextField text6=new JTextField();
        JTextField text7=new JTextField();
        JTextField text8=new JTextField();

        JButton buttonok =new JButton("确定");
        JButton buttokexit=new JButton("重置");

        GroupLayout groupLayout2=new GroupLayout(panel1);
        GroupLayout.SequentialGroup hgroup2=groupLayout2.createSequentialGroup();
        hgroup2.addContainerGap(1,5);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label5,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label6,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label8,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(buttonok,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(1,5);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(text1,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text2,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text3,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text4,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text5,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text6,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text7,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text8,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(buttokexit,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));

        // 此处是被放弃的布局 因为很丑 原来是4 和 7
        //hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(labl4,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(label7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        //hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(text4,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text7,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE));


        GroupLayout.SequentialGroup vgroup2=groupLayout2.createSequentialGroup();
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label5,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text5,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label6,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text6,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label8,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text8,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(buttonok,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(buttokexit,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setHorizontalGroup(hgroup2);
        groupLayout2.setVerticalGroup(vgroup2);
        panel1.setLayout(groupLayout2);







        GroupLayout groupLayout1=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=groupLayout1.createSequentialGroup();
        hgroup.addGroup(groupLayout1.createParallelGroup().addComponent(panel1,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgroup=groupLayout1.createSequentialGroup();
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(panel1,GroupLayout.DEFAULT_SIZE,800,GroupLayout.PREFERRED_SIZE));
        groupLayout1.setVerticalGroup(vgroup);
        groupLayout1.setHorizontalGroup(hgroup);
        this.setLayout(groupLayout1);



        buttonok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(text1.getText().toString().equals("")||text2.getText().toString().equals("")||text3.getText().toString().equals("")||text4.getText().toString().equals("")||text5.getText().toString().equals("")||text6.getText().toString().equals("")||text7.getText().toString().equals("")||text8.getText().toString().equals("")){
                    JOptionPane.showMessageDialog(null,
                            "请检查数据是否填写完整",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text1.getText().length()<2||text1.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "药房名称长度不能小于2或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text2.getText().length()<2||text2.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "药品管理联系人长度不能小于2或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text3.getText().length()<3||text3.getText().length()>20){
                    JOptionPane.showMessageDialog(null,
                            "负责人电话长度不正确",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text4.getText().length()<3||text4.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "药房所属区域不正确",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text5.getText().length()<3||text5.getText().length()>16)
                {
                    JOptionPane.showMessageDialog(null,
                            "药房编码",
                            "info",
                            INFORMATION_MESSAGE);
                }

                else if(text6.getText().length()<3||text6.getText().length()>30){
                    JOptionPane.showMessageDialog(null,
                            "药房地址长度错误",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text7.getText().length()<0){
                    JOptionPane.showMessageDialog(null,
                            "地区编码不正确",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text8.getText().length()<3||text8.getText().length()>36){
                    JOptionPane.showMessageDialog(null,
                            "药房区域长度不正确",
                            "info",
                            INFORMATION_MESSAGE);
                }

                else{

                    //drugs_name	drugs_peo	drugs_pro_call	drugs_area	drugs_address	drugs_room_code	 address_code	drugs_room_area_address

                    //添加所有数据
                    Map<String,Object> map=new HashMap<String, Object>();
                    //随机生成ID
                    int random= (int) ((Math.random()*10000)+Math.random()*101010);
                    map.put("drugs_id",random);
                    map.put("drugs_name",text1.getText().toString());
                    map.put("drugs_peo",text2.getText().toString());
                    map.put("drugs_pro_call",text3.getText().toString());
                    map.put("drugs_area",text4.getText().toString());
                    map.put("drugs_address",text5.getText().toString());
                    map.put("drugs_room_code",text6.getText().toString());
                    map.put("address_code",text7.getText().toString());
                    map.put("drugs_room_area_address",text8.getText().toString());
                    room.insertDrugs_room(map);
                    buttokexit.doClick();
                }
            }
        });


        buttokexit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                text1.setText("");
                text2.setText("");
                text3.setText("");
                text4.setText("");
                text5.setText("");
                text6.setText("");
                text7.setText("");
                text8.setText("");
            }
        });

    }
}
