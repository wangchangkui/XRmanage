package XR.ui;

import XR.Model.Produce;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DeleteProduce extends JPanel {
    public DeleteProduce() {
        Produce produce = new Produce();
        JPanel top = new JPanel();
        top.setBorder(new TitledBorder("搜索条件"));
        JLabel lbl1 = new JLabel("生产单位编号:");
        JLabel lbl2 = new JLabel("生产单位名称:");
        JLabel lab3 = new JLabel("生产单位简码:");
        JLabel lab4 = new JLabel("你可以选择一个所知的内容即可搜索");
        lab4.setForeground(Color.cyan);
        JTextField textName = new JTextField();
        JTextField textID = new JTextField();
        JTextField cone = new JTextField();
        lbl2.setForeground(new Color(3, 169, 244));
        JButton button = new JButton("搜索");
        /*
         * 这是第一个区域
         * */
        //垂直
        GroupLayout groupLayout1 = new GroupLayout(top);
        GroupLayout.SequentialGroup hg = groupLayout1.createSequentialGroup();
        hg.addContainerGap(10, 10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE).addComponent(lbl2, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE).addComponent(lab3, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10, 10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(textID, GroupLayout.DEFAULT_SIZE, 300, GroupLayout.PREFERRED_SIZE).addComponent(textName, GroupLayout.DEFAULT_SIZE, 300, GroupLayout.PREFERRED_SIZE).addComponent(cone, GroupLayout.DEFAULT_SIZE, 300, GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10, 10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(button, GroupLayout.DEFAULT_SIZE, 100, GroupLayout.PREFERRED_SIZE).addComponent(lab4, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE));


        //水平
        GroupLayout.SequentialGroup vg = groupLayout1.createSequentialGroup();
        vg.addContainerGap(10, 40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE).addComponent(textID, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE).addComponent(button, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10, 40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl2, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE).addComponent(textName, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE).addComponent(lab4, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10, 40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lab3, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE).addComponent(cone, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE));
        groupLayout1.setVerticalGroup(vg);
        groupLayout1.setHorizontalGroup(hg);
        top.setLayout(groupLayout1);




        /*
         * 这是第三个区域
         * */
        JPanel footer = new JPanel();
        footer.setBorder(new TitledBorder("搜索数据内容"));


        //废弃数据
//        Object[] info={"编号","生产内容"};
//        Object[][] data={{"001","超级管理员"},{"002","普通管理员"}};


        JTable tables = new JTable();
        DefaultTableModel tableModel = (DefaultTableModel) tables.getModel();

        tables.setShowGrid(true);
        tables.setRowHeight(30);
        tables.setGridColor(new Color(3, 169, 244));
        tables.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.getTableHeader().setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.setPreferredScrollableViewportSize(new Dimension(10, 500));
        JButton button3 = new JButton("删除");


        //垂直
        GroupLayout groupLayout3 = new GroupLayout(footer);
        GroupLayout.SequentialGroup hgroup3 = groupLayout3.createSequentialGroup();
        hgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tables.getTableHeader(), GroupLayout.DEFAULT_SIZE, 800, GroupLayout.PREFERRED_SIZE).addComponent(tables, GroupLayout.DEFAULT_SIZE, 800, GroupLayout.PREFERRED_SIZE));
        hgroup3.addContainerGap(10, 50);
        hgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(button3, GroupLayout.DEFAULT_SIZE, 100, GroupLayout.PREFERRED_SIZE));
        hgroup3.addGroup(groupLayout3.createParallelGroup());
        //水平
        GroupLayout.SequentialGroup vgroup3 = groupLayout3.createSequentialGroup();
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tables.getTableHeader(), GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE).addComponent(button3, GroupLayout.DEFAULT_SIZE, 30, GroupLayout.PREFERRED_SIZE));

        vgroup3.addContainerGap(1, 2);
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tables, GroupLayout.DEFAULT_SIZE, 400, GroupLayout.PREFERRED_SIZE));

        groupLayout3.setVerticalGroup(vgroup3);
        groupLayout3.setHorizontalGroup(hgroup3);
        footer.setLayout(groupLayout3);

        /*
         * 下面是三个面板生成
         * */
        GroupLayout group = new GroupLayout(this);
        //水平
        GroupLayout.SequentialGroup hgroup = group.createSequentialGroup();

        //太丑了 删除这个代码
        //hgroup.addContainerGap();
        hgroup.addGroup(group.createParallelGroup().addComponent(top, GroupLayout.PREFERRED_SIZE, 1200, GroupLayout.PREFERRED_SIZE)
                .addComponent(footer, GroupLayout.PREFERRED_SIZE, 1200, GroupLayout.PREFERRED_SIZE));

        //垂直
        GroupLayout.SequentialGroup vgropu = group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(top, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE));
        vgropu.addGroup(group.createParallelGroup().addComponent(footer, GroupLayout.PREFERRED_SIZE, 500, GroupLayout.PREFERRED_SIZE));


        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);


        tableModel.addColumn("产品ID");
        tableModel.addColumn("产品名称");
        tableModel.addColumn("联系人");
        tableModel.addColumn("联系电话");
        tableModel.addColumn("生成地址");
        tableModel.addColumn("备注");
        tableModel.addColumn("产品简码");
        tableModel.addColumn("产品编码");
        tableModel.addColumn("销售地址");


        //设置对象的大小
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = tableModel.getRowCount();
                int s=0;
                while (s<tableModel.getRowCount()){
                    tableModel.removeRow(s);
                }

                List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
                Map<String, Object> map = null;

                //单独判断
                String textIDs = textID.getText().toString();
                String Codes = textName.getText().toString();
                String encodes = cone.getText().toString();


                if (textIDs.isEmpty() && Codes.isEmpty() && encodes.isEmpty()) {
                    System.out.println("你没有输入任何条件");
                } else if (!textIDs.isEmpty() && !Codes.isEmpty() && !encodes.isEmpty()) {

                    list = produce.SelectAllif(textName.getText().toString(), textID.getText().toString(), cone.getText().toString());
                } else if ((!textIDs.isEmpty()) && Codes.isEmpty() && encodes.isEmpty()) {

                    list = produce.SelectByID(textIDs);
                } else if (textIDs.isEmpty() && (!Codes.isEmpty()) && encodes.isEmpty()) {

                    list = produce.SelectByCode(Codes);
                } else if (textIDs.isEmpty() && Codes.isEmpty() && (!encodes.isEmpty())) {

                    list = produce.SelectByCode(encodes);
                } else if ((!textIDs.isEmpty()) && (!Codes.isEmpty()) && encodes.isEmpty()) {
                    list = produce.SelectByID(textIDs);
                } else if ((!textIDs.isEmpty()) && Codes.isEmpty() && (!encodes.isEmpty())) {
                    list = produce.SelectByID(textIDs);
                } else if (textIDs.isEmpty() && (!Codes.isEmpty()) && (!encodes.isEmpty())) {
                    list = produce.SelectByCode(Codes);
                }


                if (!list.isEmpty()) {
                    //list 长度
                    int count = list.size();
                    for (int i = 0; i < count; i++) {
                        map = list.get(i);
                        Object[] obj = new String[]{map.get("Produce_id").toString(), map.get("Produce_name").toString(), map.get("Produce_peo").toString(), map.get("Produce_call").toString(), map.get("Produce_addrucess").toString(), map.get("Produece_forget").toString(), map.get("Produce_Code").toString(), map.get("Produce_encode").toString(), map.get("Produce_Sell").toString()};
                        tableModel.addRow(obj);
                    }


                }


            }
        });

        //删除 1.获取选中行的Id
        final String[] ID = {""};
        tables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                //选择行
                int x=tables.getSelectedRow();
                //选择列
                int y=tables.getSelectedColumn();


                if(x!=-1&&y!=-1){
                    while (y>0){
                        y--;
                    }
                    ID[0] =tableModel.getValueAt(x,y).toString();
                }
            }
        });

        tables.getTableHeader().setReorderingAllowed(false);
        //删除数据
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!(ID[0].equals(""))){
                    produce.DeleteByID(ID[0]);
                    int row=tableModel.getRowCount();
                    for(int i=0;i<row;i++){
                        if(tableModel.getValueAt(i,0).equals(ID[0])){
                            tableModel.removeRow(i);
                            ID[0]="";
                            break;
                        }
                    }
                }
            }
        });
    }
}
