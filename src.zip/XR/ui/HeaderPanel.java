package XR.ui;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class HeaderPanel extends JPanel implements Serializable{
    private static final long serialVersionUID = 1L;
    public HeaderPanel(){
    }
    public Image getImage(){
        return Toolkit.getDefaultToolkit().getImage("D:/javauml/recose/image/head.jpg");
    }
    public void paintComponent(Graphics g){
        Graphics2D g2d=(Graphics2D)g;
        g2d.drawImage(getImage(),0,0,this);
    }
}
