package XR.ui;

import javax.swing.*;
import java.awt.*;

public class Right extends JPanel {
    private static final long serialVersionUID = 1L;
    public Right() {
    }
    public Image getImage(){
        return Toolkit.getDefaultToolkit().getImage("D:/javauml/recose/image/foot.jpg");
    }
    public void paintComponent(Graphics g){
        Graphics2D g2d=(Graphics2D)g;
        //g2d.drawImage(getImage(),0,0,1200,100,this);
        g2d.drawImage(getImage(),0,0,this);
    }
}
