package XR.ui;

import XR.Model.Drugs_class;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Midirforce extends JPanel {
    public Midirforce(){

        Drugs_class drugs_class=new Drugs_class();
        JPanel panel1=new JPanel();
        panel1.setBorder(new TitledBorder("药品分类"));
        JLabel label1=new JLabel("药品分类编码");
        JLabel label2=new JLabel("药品分类名称");


        JTextField text1=new JTextField();
        JTextField text2=new JTextField();


        JButton buttonok =new JButton("确定");
        JButton buttokexit=new JButton("重置");

        GroupLayout groupLayout2=new GroupLayout(panel1);
        GroupLayout.SequentialGroup hgroup2=groupLayout2.createSequentialGroup();
        hgroup2.addContainerGap(1,5);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(buttonok,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(1,5);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(text1,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text2,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(buttokexit,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));

        // 此处是被放弃的布局 因为很丑 原来是4 和 7
        //hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(labl4,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(label7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        //hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(text4,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text7,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE));


        GroupLayout.SequentialGroup vgroup2=groupLayout2.createSequentialGroup();
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));

        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(buttonok,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(buttokexit,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setHorizontalGroup(hgroup2);
        groupLayout2.setVerticalGroup(vgroup2);
        panel1.setLayout(groupLayout2);







        GroupLayout groupLayout1=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=groupLayout1.createSequentialGroup();
        hgroup.addGroup(groupLayout1.createParallelGroup().addComponent(panel1,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgroup=groupLayout1.createSequentialGroup();
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(panel1,GroupLayout.DEFAULT_SIZE,800,GroupLayout.PREFERRED_SIZE));
        groupLayout1.setVerticalGroup(vgroup);
        groupLayout1.setHorizontalGroup(hgroup);
        this.setLayout(groupLayout1);


        buttonok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(text1.getText().toString().equals("")||text2.getText().toString().equals("")){
                    JOptionPane.showMessageDialog(null,
                            "请检查数据是否填写完整",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text1.getText().length()<2||text1.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "药品分类编码长度不能小于2或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text2.getText().length()<2||text2.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "分类名称长度不能小于2或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }


                else{
                    //添加所有数据
                    Map<String,Object> map=new HashMap<String, Object>();
                    //随机生成ID
                    int random= (int) ((Math.random()*10000)+Math.random()*101010);
                    map.put("drugs_id",random);
                    map.put("drugs_code",text1.getText().toString());
                    map.put("drugs_name",text2.getText().toString());
                    drugs_class.insertDrugs_room(map);
                    buttokexit.doClick();
                }
            }
        });

        buttokexit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                text1.setText("");
                text2.setText("");
            }
        });
    }
}
