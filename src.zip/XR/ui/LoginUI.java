package XR.ui;



import XR.Model.UserModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class LoginUI extends JPanel implements ActionListener{
    JPanel jp=new JPanel();
    JTextField username;
    JPasswordField password;
    MainFrame contentPanle=null;
    public LoginUI(MainFrame panel){
        this.contentPanle=panel;
        this.setName("LoginUI");
        jp.setLayout(null);
        this.setLayout(null);
        initComponent();
    }

    public void initComponent(){
        JLabel lable=new JLabel();
        lable.setFont(new Font("微软雅黑",Font.PLAIN,16));
        lable.setBounds(0,0,57,17);
        lable.setForeground(new Color(255,255,255));
        lable.setText("账号：");
        jp.add(lable);

        username = new  JTextField();
        username.setBounds(50,0,191 ,22);
        username.setForeground(new Color(59, 209,255));
        username.setOpaque(false);
        jp.add(username);

        JLabel lable1=new JLabel();
        lable1.setFont(new Font("微软雅黑",Font.PLAIN,16));
        lable1.setBounds(0,30,57,17);
        lable1.setForeground(new Color(255,255,255));
        lable1.setText("密码：");
        jp.add(lable1);

        password = new JPasswordField();
        password.setBounds(50,30,191,22);
        password.setForeground(new Color(255,255,255));
        password.setOpaque(false);
        jp.add(password);

        JButton button=new JButton();
        button.setBounds(0 ,60,240,40);
        button.setBackground(new Color(57,149,136));
        button.setText("登录");
        button.addActionListener(this);
        jp.add(button);
        jp.setOpaque(false);
       // jp.setBounds(850,650,400,400);

        GroupLayout grop=new GroupLayout(this);
        GroupLayout.SequentialGroup hgrop=grop.createSequentialGroup();
        hgrop.addContainerGap(1,Short.MAX_VALUE);
        hgrop.addComponent(jp,GroupLayout.PREFERRED_SIZE,400,GroupLayout.PREFERRED_SIZE);
        grop.setHorizontalGroup(hgrop);
        GroupLayout.SequentialGroup vgrop=grop.createSequentialGroup();
        vgrop.addContainerGap(1,Short.MAX_VALUE);
        vgrop.addComponent(jp,GroupLayout.PREFERRED_SIZE,160,GroupLayout.PREFERRED_SIZE);
        grop.setVerticalGroup(vgrop);
        this.setLayout(grop);

        //this.add(jp);
    }
    public void paintComponent(Graphics g){
        Graphics2D g2d=(Graphics2D) g;
        Image img=Toolkit.getDefaultToolkit().getImage("D:/javauml/recose/image/image.jpg");
        g2d.drawImage(img,0,0,(int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(),(int)Toolkit.getDefaultToolkit().getScreenSize().getHeight(),null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if("".equals(username.getText().toString())||"".equals(password.getText().toString())){
            JOptionPane.showMessageDialog(null,
                   "账号或密码框不能为空",
                       "登录信息",
                   INFORMATION_MESSAGE);
        }
        else if(username.getText().toString().length()<5||password.getText().toString().length()>16||username.getText().toString().length()>16||password.getText().toString().length()<5){
            JOptionPane.showMessageDialog(null,
                    "账号或密码长度不正确",
                    "登录信息",
                    INFORMATION_MESSAGE);
        }
        else{
            UserModel userModel=new UserModel();
            Map infos=userModel.Login(username.getText(),password.getText());
            if(infos.isEmpty()){
                JOptionPane.showMessageDialog(null,"登录错误 账号或密码错误||数据库未打开","登录信息", JOptionPane.ERROR_MESSAGE);
            }

            else if(infos.get("flag").equals("1")){
                contentPanle.switchPanl("Manager",infos);
            }
            else{
                contentPanle.switchPanl("UserManger",infos);
            }
        }

    }

}
