package XR.ui;


import XR.Model.UserModel;
import XR.userComponet.Jtable;



import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class DeleteAccount extends JPanel {
    public Map<String,String> map;
    public DeleteAccount() throws SQLException {

        //设置数据的内容
        UserModel userModel=new UserModel();
        int count=userModel.countRow();
        String[] values=new String[count];
        Object[] IDcoulunms = new Object[count];
        Object[] Username=new Object[count];
        map=new HashMap<String, String>();

        //浏览表
        JPanel seePanel=new JPanel();
        seePanel.setBorder(new TitledBorder("数据内容"));

        //数据库写入
        ResultSet rs=userModel.infos();

        Jtable tables=new Jtable();
        DefaultTableModel tableModel=(DefaultTableModel) tables.getModel();
        //修改为此处添加数据与
        int i=0;
        while (rs.next()){
            IDcoulunms[i]=rs.getString("UserID");
            Username[i]=rs.getString("username");
            values[i]=rs.getString("flagname");
            i++;
        }
        rs.close();


        tableModel.addColumn("用户ID",IDcoulunms);
        tableModel.addColumn("用户名称",Username);
        tableModel.addColumn("当前权限名称",values);


        final int[] tableCount = new int[1];


        //线程刷新数据
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        tableCount[0] = tableModel.getRowCount();
                        try {
                            int count = userModel.countRow();
                            if (tableCount[0] != count) {
                                int i = 0;
                                while (i < tableCount[0]) {
                                    tableModel.removeRow(i);
                                }
                                ResultSet rs=userModel.Listinfos();
                                while (rs.next()){
                                    Object[] os={rs.getString("UserID"),rs.getString("Username"),rs.getString("flagname")};
                                    tableModel.addRow(os);
                                }

                            }
                        } catch (Exception e) {
                            e.toString();
                        }
                        Thread.sleep(3000);
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

        tables.setShowGrid(true);
        tables.setRowHeight(30);
        tables.setGridColor(new Color(3,169,244));
        tables.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.getTableHeader().setBorder(new EtchedBorder(EtchedBorder.LOWERED));

        //滑动
        tables.setPreferredScrollableViewportSize(new Dimension(10,500));

        GroupLayout groupLayout=new GroupLayout(seePanel);
        GroupLayout.SequentialGroup hg=groupLayout.createSequentialGroup();
        hg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,800,GroupLayout.PREFERRED_SIZE).addComponent(tables,GroupLayout.DEFAULT_SIZE,800,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vg=groupLayout.createSequentialGroup();

        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables,GroupLayout.DEFAULT_SIZE,600,GroupLayout.PREFERRED_SIZE));

        groupLayout.setHorizontalGroup(hg);
        groupLayout.setVerticalGroup(vg);
        seePanel.setLayout(groupLayout);



        //底部
        JPanel infos=new JPanel();
        infos.setBorder(new TitledBorder("删除用户"));
        JButton button=new JButton("删除");
        JLabel str=new JLabel("请输入你要删除用户编号:");
        JTextField textID=new JTextField();
        GroupLayout groupLayout2=new GroupLayout(infos);
        GroupLayout.SequentialGroup vgroups=groupLayout2.createSequentialGroup();
        vgroups.addContainerGap(10,30);
        vgroups.addGroup(groupLayout2.createParallelGroup().addComponent(str,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(textID,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));

        GroupLayout.SequentialGroup hgroups=groupLayout2.createSequentialGroup();
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(str,GroupLayout.DEFAULT_SIZE,50,GroupLayout.PREFERRED_SIZE));
        hgroups.addContainerGap(10,30);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(textID,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        hgroups.addContainerGap(10,30);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setVerticalGroup(vgroups);
        groupLayout2.setHorizontalGroup(hgroups);
        infos.setLayout(groupLayout2);



        //主要界面
        GroupLayout group=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=group.createSequentialGroup();
        hgroup.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE)
        .addComponent(infos,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgropu=group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,600,GroupLayout.PREFERRED_SIZE));
        vgropu.addGroup(group.createParallelGroup().addComponent(infos,GroupLayout.PREFERRED_SIZE,200,GroupLayout.PREFERRED_SIZE));
        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);
        tables.getTableHeader().setReorderingAllowed(false);


        //事件
        tables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x=tables.getSelectedRow();
                int y=tables.getSelectedColumn();
                try {
                    switch (y){
                        case 0:
                            textID.setText(tables.getValueAt(x,y).toString());
                            break;
                        case 1:
                            textID.setText(tables.getValueAt(x,y-1).toString());
                            break;
                        case 2:
                            textID.setText(tables.getValueAt(x,y-2).toString());
                    }
                }
                catch (Exception es){
                    System.out.println(es.toString());
                }

            }
        });

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textID.equals("")){
                    JOptionPane.showMessageDialog(null,
                            "添加失败 用户ID为空",
                            "数据库",
                            INFORMATION_MESSAGE);
                }
                else{
                    //获取表的总长度
                    String Uid=textID.getText().toString();
                    userModel.DeleteWithID(Uid);
                    tableCount[0] =tableModel.getRowCount();
                    for(int i = 0; i< tableCount[0]; i++){
                            if(tables.getValueAt(i,0).equals(Uid)){
                                tableModel.removeRow(i);
                            }
                    }
                }
            }
        });
    }
}
