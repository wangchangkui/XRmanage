package XR.ui;

import XR.userComponet.MenuLable;

import javax.swing.*;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Map;

public class Navgiter  extends JPanel {
    private static final long serialVersionUID = 1L;
    JLabel Lables;
    public Navgiter(MainFrame mainFram,Manager panel) {
        this.setPreferredSize(new Dimension(200,0));
        this.setBorder(new MatteBorder(2,2,2,2,new Color(233,242,255)));
        this.setLayout(null);
        Lables =new MenuLable(" 账 号 管 理 ","account",panel);
        Lables.setBounds(9,21,180,34);
        this.add(Lables);

        Lables =new MenuLable(" 生 产 单 位 管 理 ","produce",panel);
        Lables.setBounds(9,71,180,34);
        this.add(Lables);

        Lables =new MenuLable(" 供 货 产 单 位 管 理 ","complay",panel);
        Lables.setBounds(9,121,180,34);
        this.add(Lables);

        Lables =new MenuLable(" 药 品 信 息  管 理 ","midirproduce",panel);
        Lables.setBounds(9,171,180,34);
        this.add(Lables);

        Lables =new MenuLable(" 药 房 信 息  管 理 ","midirroom",panel);
        Lables.setBounds(9,221,180,34);
        this.add(Lables);

        Lables =new MenuLable(" 药 品 类 别  管 理 ","midirfoce",panel);
        Lables.setBounds(9,271,180,34);
        this.add(Lables);

        Lables =new MenuLable(" 退 出 系 统 ","exit",null);
        Lables.setBounds(9,321,180,34);
        Lables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Map<String ,String> map=new HashMap<String, String>();
                map.put("flag","0");
                map.put("username","");
                mainFram.switchPanl("LoginUI", map);
                JOptionPane.showMessageDialog(null,"成功退出系统","退出系统",JOptionPane.INFORMATION_MESSAGE);
            }
        });
        this.add(Lables);
    }

    //背景颜色
    public Image getImage(){
        return Toolkit.getDefaultToolkit().getImage("D:/javauml/recose/image/menu.jpg");
    }
    public void paintComponent(Graphics g){
        Graphics2D g2d=(Graphics2D)g;
        g2d.drawImage(getImage(),0,0,this);
    }
}
