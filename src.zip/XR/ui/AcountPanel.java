package XR.ui;

import XR.Model.Manager;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class AcountPanel extends JPanel {
    public Map<String,String> has;
    public String IDs;
    public AcountPanel() throws SQLException{

        //对应的Model
        has=new HashMap<String, String>();

        Manager manager=new Manager();
        JPanel top=new JPanel();
        JPanel middl=new JPanel();
        JPanel footer=new JPanel();

        top.setBorder(new TitledBorder("添加账号类型"));
        JLabel lbl1=new JLabel("新添加账号类型:");
        JComboBox box=new JComboBox();
        box.addItem("普通管理员权限");
        box.addItem("超级管理员权限");
        JTextField textName=new JTextField();
        JLabel lbl2=new JLabel("账号类型不能超过6个字符");
        lbl2.setForeground(new Color(3,169,244));
        JButton button=new JButton("添加");




        /*
        * 这是第一个区域
        * */
        //垂直
        GroupLayout groupLayout1=new GroupLayout(top);
        GroupLayout.SequentialGroup hg=groupLayout1.createSequentialGroup();
        hg.addContainerGap(10,10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(textName,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,20);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(box,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,20);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,20);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));


        //水平
        GroupLayout.SequentialGroup vg=groupLayout1.createSequentialGroup();
        vg.addContainerGap(10,30);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(textName, GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(box,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lbl2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout1.setVerticalGroup(vg);
        groupLayout1.setHorizontalGroup(hg);
        top.setLayout(groupLayout1);

        /*
         * 这是第二个区域
         * */



        /*
        * 删除数据的部分
        * */



        //设置被删除的ID



        middl.setBorder(new TitledBorder("删除账号类型"));
        JLabel Dlab1=new JLabel("删除的账号类型:");
        JComboBox jcombo=new JComboBox();
        jcombo.addItem("请选择要删除的类型");
        JButton button2=new JButton("删除");
        jcombo=EditBox(jcombo);


        //垂直
        GroupLayout groupLayout2=new GroupLayout(middl);
        GroupLayout.SequentialGroup hgroup2=groupLayout2.createSequentialGroup();
        hgroup2.addContainerGap(10,10);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(Dlab1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(10,10);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(jcombo,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(10,20);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(button2,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        //水平
        GroupLayout.SequentialGroup vgroup=groupLayout2.createSequentialGroup();
        vgroup.addContainerGap(10,30);
        vgroup.addGroup(groupLayout2.createParallelGroup().addComponent(Dlab1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(jcombo,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setHorizontalGroup(hgroup2);
        groupLayout2.setVerticalGroup(vgroup);
        middl.setLayout(groupLayout2);


        /*
         * 这是第三个区域
         * */

        footer.setBorder(new TitledBorder("查看账号类型"));
        Object[] info={"编号","管理权限名称"};

        //设置表格的行数
        Object[][] data = new Object[manager.count()][2];
        ResultSet rs2=manager.getAllManager();
       // System.out.println(rs2.getMetaData().getColumnCount());  //获取列数
        int i=0;
        while (rs2.next()){
            data[i][0]=rs2.getString("ID");
            data[i][1]=rs2.getString("maneger");
            i++;
        }

        DefaultTableModel tableModel = new DefaultTableModel(data,info);
        JTable tables=new JTable(tableModel);
        tables.setShowGrid(true);
        tables.setRowHeight(30);
        tables.setGridColor(new Color(3,169,244));
        tables.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.getTableHeader().setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.setPreferredScrollableViewportSize(new Dimension(10,500));



        //鼠标点击事件
        tables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //获取行
               int i=tables.getSelectedRow();
               int j=tables.getSelectedColumn();
               if(j==0){
                   JOptionPane.showMessageDialog(null,
                           "所选列是不能被修改的",
                           "Info",
                           INFORMATION_MESSAGE);
               }
            }
        });



        //检测值被修改
        tables.getModel().addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int i=tables.getSelectedRow();
                int j=tables.getSelectedColumn();
                try {
                    if (i == -1 || j == -1 || j == 0) {
                        System.out.println("Error");
                    } else {
                        String ID = tables.getValueAt(i, j - 1).toString();
                        String Name = tables.getValueAt(i, j).toString();
                        has.put(ID, Name);
                    }
                }
                catch (Exception es){

                }

            }
        });


        tables.getTableHeader().setReorderingAllowed(false);



        JButton button3=new JButton("提交修改");
        JButton button4=new JButton("放弃修改");





        //垂直
        GroupLayout groupLayout3=new GroupLayout(footer);
        GroupLayout.SequentialGroup hgroup3=groupLayout3.createSequentialGroup();
        hgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,800,GroupLayout.PREFERRED_SIZE).addComponent(tables,GroupLayout.DEFAULT_SIZE,800,GroupLayout.PREFERRED_SIZE));
        hgroup3.addContainerGap(10,50);
        hgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(button3,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE).addComponent(button4,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        hgroup3.addGroup(groupLayout3.createParallelGroup());
        //水平
        GroupLayout.SequentialGroup vgroup3=groupLayout3.createSequentialGroup();
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));

        vgroup3.addContainerGap(1,2);
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tables,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(button4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));

        groupLayout3.setVerticalGroup(vgroup3);
        groupLayout3.setHorizontalGroup(hgroup3);
        footer.setLayout(groupLayout3);

        /*
        * 下面是三个面板生成
        * */
        GroupLayout group=new GroupLayout(this);
        //水平
        GroupLayout.SequentialGroup hgroup=group.createSequentialGroup();

        //太丑了 删除这个代码
        //hgroup.addContainerGap();
        hgroup.addGroup(group.createParallelGroup().addComponent(top,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE)
                .addComponent(middl,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE)
                .addComponent(footer,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE));


        //垂直
        GroupLayout.SequentialGroup vgropu=group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(top,GroupLayout.PREFERRED_SIZE,120,GroupLayout.PREFERRED_SIZE));
        vgropu.addGroup(group.createParallelGroup().addComponent(middl,GroupLayout.PREFERRED_SIZE,120,GroupLayout.PREFERRED_SIZE));
        vgropu.addGroup(group.createParallelGroup().addComponent(footer,GroupLayout.PREFERRED_SIZE,500,GroupLayout.PREFERRED_SIZE));


        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);


        //添加
        JComboBox finalJcombo = jcombo;



        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if("".equals(textName.getText().toString())){
                    JOptionPane.showMessageDialog(null,
                            "添加失败 为输入账号类型",
                            "数据库",
                            INFORMATION_MESSAGE);
                }
                else{
                    Integer flag=2;
                    if(box.getSelectedItem().toString().equals("超级管理员权限")){
                        flag=1;
                    }

                    System.out.println(box.getSelectedItem().toString());

                    Manager manager=new Manager();
                    //添加权限
                    try {
                        int a=manager.insertManeger(textName.getText().toString(),flag);
                        if (a==1){
                            String datas=manager.ID(textName.getText().toString());
                            if(datas.equals("")){
                                JOptionPane.showMessageDialog(null,
                                        "代码出现了问题，检查AcountPanel类面板",
                                        "数据库",
                                        INFORMATION_MESSAGE);
                            }
                            else{
                                finalJcombo.addItem(textName.getText().toString());
                                Object[] os={datas,textName.getText().toString()};
                                tableModel.addRow(os);
                            }

                        }
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }


                }
            }
        });


        /*
         * 删除管理员
         * */
        JComboBox finalJcombo1 = jcombo;


        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!finalJcombo1.getSelectedItem().toString().equals("请选择要删除的类型")){
                    String managername= finalJcombo1.getSelectedItem().toString();
                    try {
                        manager.DeleteManger(managername);
                        //移除指定行
                        int row=tableModel.getRowCount();
                        for (int i=0;i<row;i++){
                            if(tables.getValueAt(i,1).equals(managername)){
                                tableModel.removeRow(i);
                            }
                        }


                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                    finalJcombo1.removeItem(managername);
                }
            }
        });



        //修改
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //获取map中的值，并且无重复

                if (has.isEmpty()) {
                    JOptionPane.showMessageDialog(null,
                            "没有修改的值",
                            "Info",
                            INFORMATION_MESSAGE);
                } else {
                    Set<String> seting = has.keySet();
                    for (String s : seting) {
                        try {
                            manager.UpdataInfo(s, has.get(s));
                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                            JOptionPane.showMessageDialog(null,
                                    "修改失败 检查错误信息",
                                    "Info",
                                    INFORMATION_MESSAGE);
                        }
                    }
                    JOptionPane.showMessageDialog(null,
                            "当前修改成功",
                            "Info",
                            INFORMATION_MESSAGE);
                }
            }
        });



        //放弃修改
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                has.clear();
                JOptionPane.showMessageDialog(null,
                        "已经取消修改",
                        "Info",
                        INFORMATION_MESSAGE);

            }
        });
    }




    public JComboBox EditBox(JComboBox box) throws SQLException {
        Manager managers=new Manager();
        ResultSet getRs=managers.getAllManager();
        while (getRs.next()){
            box.addItem(getRs.getString("maneger"));
        }
        return box;
    }



}


