package XR.ui;

import XR.ui.UserManneger.UserManger;
import XR.userComponet.LinkDocLable;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.Calendar;
import java.util.Map;


public class MainFrame extends JFrame {
    JPanel pnCneter,pnlsouth;
    private final int Width =1200;
    private final int Heigth=900;

    private static Map flag;
    public MainFrame(){
        //设置窗口大小
        this.setSize(Width,Heigth);
        //窗口标题
        this.setTitle("欣然药品管理系统");
        pnCneter =new JPanel();
        pnlsouth =new JPanel();


        pnCneter.setLayout(new CardLayout());
        pnlsouth.setLayout(null);


        JLabel lblTime=new JLabel();
        lblTime.setBounds(940,0,300,28);
        lblTime.setForeground(Color.GREEN);


        //底部添加自定义的标签
        pnlsouth.setPreferredSize(new Dimension(0,28));
        LinkDocLable lk=new LinkDocLable("欣然药品管理系统阅读说明书");
        lk.setBounds(0,0,280,28);
        pnlsouth.add(lk);

        //底部边框设置边框
        pnlsouth.setBorder(new LineBorder(Color.cyan,1,true));
        //线程启动获取时间
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    try {
                        Thread.sleep(1000);

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    //初始化日历
                    Calendar cal=Calendar.getInstance();
                    lblTime.setText("当前时间："+cal.get(Calendar.YEAR)+"年"+(cal.get(Calendar.MONTH)+1)+"月"+cal.get(Calendar.DAY_OF_MONTH)+"日"+cal.get(Calendar.HOUR_OF_DAY)+":"+cal.get(Calendar.MINUTE)+":"+cal.get(Calendar.SECOND));
                }
            }
        }).start();

        //底部加载时间标签
        pnlsouth.add(lblTime);

        //中间加载图片标签
        LoginUI lUI=new LoginUI(this);
        pnCneter.add(lUI,lUI.getName());



        /*
        * 切换面板不能获取当前用户数据，2020-11-1
        * 此处BUG 已被修改 2020-11-9
        * */
//        UserManger userManger=new UserManger(this,this.flag);
//        pnCneter.add(userManger,userManger.getName());


        this.add(pnCneter);
        this.add(pnlsouth,BorderLayout.SOUTH);


    }
    public void switchPanl(String name, Map infos){
        this.flag= infos;

        //整个项目添加中间和底部标签
        Manager manager=new Manager(this,this.flag);
        pnCneter.add(manager,manager.getName());

        UserManger userManger=new UserManger(this,this.flag);
        pnCneter.add(userManger,userManger.getName());

        CardLayout card=(CardLayout)pnCneter.getLayout();
        card.show(pnCneter,name);
    }

}
