package XR.ui;

import XR.Model.Manager;
import XR.Model.UserModel;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;


public class SeeAcountAndEdit extends JPanel {
    public SeeAcountAndEdit() throws SQLException {


        //当前jcom选定的状态
        final String[] befocSelect = {null};

        final ArrayList[] list = {null};

        UserModel userModel=new UserModel();
        //这里是顶部查询区域
        JPanel panel1=new JPanel();
        panel1.setBorder(new TitledBorder("搜索你想要查看数据的编号"));
        JLabel label1=new JLabel("查询的用户ID:");
        JTextField textID=new JTextField();
        JButton button=new JButton("查询");

        GroupLayout groupLayout2=new GroupLayout(panel1);
        GroupLayout.SequentialGroup hgrop2=groupLayout2.createSequentialGroup();
        hgrop2.addContainerGap(10,30);
        hgrop2.addGroup(groupLayout2.createParallelGroup().addComponent(label1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        hgrop2.addContainerGap(10,30);
        hgrop2.addGroup(groupLayout2.createParallelGroup().addComponent(textID,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE));
        hgrop2.addContainerGap(10,30);
        hgrop2.addGroup(groupLayout2.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgrop2=groupLayout2.createSequentialGroup();
        vgrop2.addContainerGap(10,20);
        vgrop2.addGroup(groupLayout2.createParallelGroup()
                .addComponent(label1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE)
                .addComponent(textID,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE)
                .addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setVerticalGroup(vgrop2);
        groupLayout2.setHorizontalGroup(hgrop2);
        panel1.setLayout(groupLayout2);


        //这里是内容区域
        JPanel contentPanel=new JPanel();
        contentPanel.setBorder(new TitledBorder("数据内容"));
        JLabel lableuser=new JLabel("用户名");
        JTextField field=new JTextField();
        JLabel Laval=new JLabel("管理等级");
        final JComboBox[] jcom = {new JComboBox()};
        JButton buttonok=new JButton("修改");

        GroupLayout groupLayout3=new GroupLayout(contentPanel);
        GroupLayout.SequentialGroup hgroup3=groupLayout3.createSequentialGroup();
        hgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(lableuser,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(Laval,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(buttonok,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));

        hgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(field,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE).addComponent(jcom[0],GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgroup3=groupLayout3.createSequentialGroup();

        vgroup3.addContainerGap(10,30);
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(lableuser,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(field,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup3.addContainerGap(10,30);
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(Laval,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(jcom[0],GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup3.addContainerGap(10,30);
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(buttonok,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout3.setHorizontalGroup(hgroup3);
        groupLayout3.setVerticalGroup(vgroup3);
        contentPanel.setLayout(groupLayout3);





        GroupLayout groupLayout1=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup = groupLayout1.createSequentialGroup();
        hgroup.addGroup(groupLayout1.createParallelGroup().addComponent(panel1,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE).addComponent(contentPanel,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgroup = groupLayout1.createSequentialGroup();
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(panel1,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(contentPanel,GroupLayout.DEFAULT_SIZE,600,GroupLayout.PREFERRED_SIZE));
        groupLayout1.setHorizontalGroup(hgroup);
        groupLayout1.setVerticalGroup(vgroup);
        this.setLayout(groupLayout1);




        /*
        * 查询信息按钮处理事件
        * */
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String ID=textID.getText().toString();
                try {
                    ArrayList resultSet=userModel.SelectID(ID);
                    list[0] =resultSet;
                    field.setText((String) resultSet.get(1));
                    AcountPanel acountPanel=new AcountPanel();
                    jcom[0] =acountPanel.EditBox(jcom[0]);

                    //获取当前所对应的状态
                    for (int i=0;i<jcom[0].getItemCount();i++){
                        if(jcom[0].getItemAt(i).toString().equals(resultSet.get(3).toString())){
                            jcom[0].setSelectedIndex(i);
                        }
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        });

        jcom[0].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                befocSelect[0] =jcom[0].getSelectedItem().toString();
            }
        });

        buttonok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              if(field.getText().isEmpty()){
                  JOptionPane.showMessageDialog(null,
                          "输入框内容账号或密码为空",
                          "INFO",
                          INFORMATION_MESSAGE);
              }
              else{
                  //获取用户名是否存在
                  String str= list[0].get(3).toString();
                  int flag=userModel.NameExit(field.getText().toString());
                  if(!befocSelect[0].equals(str)){
                          userModel.update(textID.getText().toString(),field.getText().toString(),jcom[0].getSelectedItem().toString());
                  }
                  else{
                      if(flag==0){
                          JOptionPane.showMessageDialog(null,
                                  "你未进行任何修改",
                                  "INFO",
                                  INFORMATION_MESSAGE);
                      }
                      else{
                          userModel.update(textID.getText().toString(),field.getText().toString(),jcom[0].getSelectedItem().toString());
                      }
                  }
              }
            }
        });
    }
}
