package XR.ui;

import XR.Model.Drugs_room;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class MidiroomSeeAndDeleteAndEdit extends JPanel {
    public MidiroomSeeAndDeleteAndEdit() throws SQLException {

        Drugs_room room=new Drugs_room();
        JPanel top=new JPanel();
        top.setBorder(new TitledBorder("搜索条件"));
        JLabel lbl1=new JLabel("药房编号:");
        JLabel lbl2=new JLabel("药房名称:");
        JLabel lab3=new JLabel("药房区域:");
        JTextField textName=new JTextField();
        JTextField textID=new JTextField();
        JTextField cone=new JTextField();
        lbl2.setForeground(new Color(3,169,244));
        JButton button=new JButton("搜索||重新加载数据");
        /*
         * 这是第一个区域
         * */
        //垂直
        GroupLayout groupLayout1=new GroupLayout(top);
        GroupLayout.SequentialGroup hg=groupLayout1.createSequentialGroup();
        hg.addContainerGap(10,10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lbl2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(textID,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE).addComponent(textName,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE).addComponent(cone,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));

        //水平
        GroupLayout.SequentialGroup vg=groupLayout1.createSequentialGroup();
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(textID, GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(textName,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lab3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(cone,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout1.setVerticalGroup(vg);
        groupLayout1.setHorizontalGroup(hg);
        top.setLayout(groupLayout1);




        /*
         * 这是第三个区域
         * */
        JPanel footer=new JPanel();
        footer.setBorder(new TitledBorder("搜索数据内容"));

        JTable tables=new JTable();
        DefaultTableModel tableModel = (DefaultTableModel) tables.getModel();

        tableModel.addColumn("药房ID");
        tableModel.addColumn("药品名称");
        tableModel.addColumn("药品管理人");
        tableModel.addColumn("管理人电话");
        tableModel.addColumn("药房所在区域");
        tableModel.addColumn("药房地址");
        tableModel.addColumn("药房编码");
        tableModel.addColumn("所在地区编码");
        tableModel.addColumn("详细销售地址");



        tables.setShowGrid(true);
        tables.setRowHeight(30);
        tables.setGridColor(new Color(3,169,244));
        tables.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.getTableHeader().setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.setPreferredScrollableViewportSize(new Dimension(10,500));
        JButton button3=new JButton("删除");
        JButton button4=new JButton("保存修改");


        //垂直
        GroupLayout groupLayout3=new GroupLayout(footer);
        GroupLayout.SequentialGroup hgroup3=groupLayout3.createSequentialGroup();
        hgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,800,GroupLayout.PREFERRED_SIZE).addComponent(tables,GroupLayout.DEFAULT_SIZE,800,GroupLayout.PREFERRED_SIZE));
        hgroup3.addContainerGap(10,50);
        hgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(button3,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE).addComponent(button4,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));

        //水平
        GroupLayout.SequentialGroup vgroup3=groupLayout3.createSequentialGroup();
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));

        vgroup3.addContainerGap(1,2);
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tables,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(button4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));

        groupLayout3.setVerticalGroup(vgroup3);
        groupLayout3.setHorizontalGroup(hgroup3);
        footer.setLayout(groupLayout3);

        /*
         * 下面是三个面板生成
         * */
        GroupLayout group=new GroupLayout(this);
        //水平
        GroupLayout.SequentialGroup hgroup=group.createSequentialGroup();

        //太丑了 删除这个代码
        //hgroup.addContainerGap();
        hgroup.addGroup(group.createParallelGroup().addComponent(top,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE)
                .addComponent(footer,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE));

        //垂直
        GroupLayout.SequentialGroup vgropu=group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(top,GroupLayout.PREFERRED_SIZE,200,GroupLayout.PREFERRED_SIZE));
        vgropu.addGroup(group.createParallelGroup().addComponent(footer,GroupLayout.PREFERRED_SIZE,500,GroupLayout.PREFERRED_SIZE));


        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);


        List<Map<String, Object>> list;
        Map<String, Object> map;
        list= room.SelectAllinfo();
        int count=list.size();
        for(int i=0;i<count;i++){
            map=list.get(i);
            Object[] obj = new String[]{map.get("drugs_id").toString(), map.get("drugs_name").toString(), map.get("drugs_peo").toString(), map.get("drugs_pro_call").toString(), map.get("drugs_area").toString(), map.get("drugs_address").toString(), map.get("drugs_room_code").toString(), map.get("address_code").toString(), map.get("drugs_room_area_address").toString()};
            tableModel.addRow(obj);
        }


        list.clear();

        List<Map<String, String>> changelist=new ArrayList<Map<String, String>>();
        final Map<String, String>[] chagemap = new Map[]{null};



        button.doClick();


        //查询功能
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = tableModel.getRowCount();
                int s=0;
                while (s<tableModel.getRowCount()){
                    tableModel.removeRow(s);
                }

                List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
                Map<String, Object> map = null;

                //单独判断
                String textIDs = textID.getText().toString();
                String Codes = textName.getText().toString();
                String encodes = cone.getText().toString();

                if (textIDs.isEmpty() && Codes.isEmpty() && encodes.isEmpty()) {
                    try {

                        list=room.SelectAllinfo();
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                } else if (!textIDs.isEmpty() && !Codes.isEmpty() && !encodes.isEmpty()) {

                    list = room.SelectAllif(textName.getText().toString(), textID.getText().toString(), cone.getText().toString());
                } else if ((!textIDs.isEmpty()) && Codes.isEmpty() && encodes.isEmpty()) {

                    list = room.SelectByID(textIDs);
                } else if (textIDs.isEmpty() && (!Codes.isEmpty()) && encodes.isEmpty()) {

                    list = room.SelectByCode(Codes);
                } else if (textIDs.isEmpty() && Codes.isEmpty() && (!encodes.isEmpty())) {

                    list = room.select_class(encodes);
                } else if ((!textIDs.isEmpty()) && (!Codes.isEmpty()) && encodes.isEmpty()) {
                    list = room.SelectByID(textIDs);
                } else if ((!textIDs.isEmpty()) && Codes.isEmpty() && (!encodes.isEmpty())) {
                    list = room.SelectByID(textIDs);
                } else if (textIDs.isEmpty() && (!Codes.isEmpty()) && (!encodes.isEmpty())) {
                    list = room.SelectByCode(Codes);
                }


                if (!list.isEmpty()) {
                    //list 长度
                    int count = list.size();
                    for (int i = 0; i < count; i++) {
                        map = list.get(i);
                        Object[] obj = new String[]{map.get("drugs_id").toString(), map.get("drugs_name").toString(), map.get("drugs_peo").toString(), map.get("drugs_pro_call").toString(), map.get("drugs_area").toString(), map.get("drugs_address").toString(), map.get("drugs_room_code").toString(), map.get("address_code").toString(), map.get("drugs_room_area_address").toString()};
                        tableModel.addRow(obj);
                    }
                }

            }
        });


        final String[] ID = {""};
        //选中删除行 1.获取选中行，获取选中数据 2.修改保存数据
        tables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x=tables.getSelectedRow();
                int y=tables.getSelectedColumn();
                if(x!=-1&&y!=-1){
                    if(y==0){
                        JOptionPane.showMessageDialog(null,
                                "所选列是不能被修改的",
                                "Info",
                                INFORMATION_MESSAGE);
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                    else{
                        while (y>0){
                            y--;
                        }
                        ID[0] =tableModel.getValueAt(x,y).toString();

                    }
                }
            }
        });


        //删除数据
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!(ID[0].equals(""))){
                    room.DeleteByID(ID[0]);
                    int row=tableModel.getRowCount();
                    for(int i=0;i<row;i++){
                        if(tableModel.getValueAt(i,0).equals(ID[0])){
                            tableModel.removeRow(i);
                            ID[0]="";
                            break;
                        }
                    }
                    //调用删除 清除数据
                    changelist.clear();
                }
            }
        });


        //检测值被修改
        tableModel.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int i=tables.getSelectedRow();
                int j=tables.getSelectedColumn();
                try {
                    if(i!=-1 && j!=-1 &&j!=0){
                        chagemap[0] =new HashMap<String, String>();
                        chagemap[0].put("drugs_id",ID[0]);
                        chagemap[0].put("drugs_name",tableModel.getValueAt(i,1).toString());
                        chagemap[0].put("drugs_peo",tableModel.getValueAt(i,2).toString());
                        chagemap[0].put("drugs_pro_call",tableModel.getValueAt(i,3).toString());
                        chagemap[0].put("drugs_area",tableModel.getValueAt(i,4).toString());
                        chagemap[0].put("drugs_address",tableModel.getValueAt(i,5).toString());
                        chagemap[0].put("drugs_room_code",tableModel.getValueAt(i,6).toString());
                        chagemap[0].put("address_code",tableModel.getValueAt(i,7).toString());
                        chagemap[0].put("drugs_room_area_address",tableModel.getValueAt(i,8).toString());
                        changelist.add(chagemap[0]);
                    }

                }
                catch (Exception es){
                    System.out.println(es.toString());
                }

            }
        });

        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(changelist.size()!=0){
                    int count=0;
                    for(int i=0;i<changelist.size();i++){
                        room.UpdateInfo(changelist.get(i));
                        count++;
                    }
                    JOptionPane.showMessageDialog(null,
                            "更新了'"+count+"'次",
                            "数据库信息",
                            INFORMATION_MESSAGE);
                }
            }
        });
    }
}

