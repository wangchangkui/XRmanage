package XR.ui;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;


import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Complay extends JPanel {
    public Complay() {

        XR.Model.Complay complays=new XR.Model.Complay();
        JPanel panel1=new JPanel();
        panel1.setBorder(new TitledBorder("添加供货单位信息"));
        JLabel label1=new JLabel("供货单位名称");
        JLabel label2=new JLabel("供货单位联系人");
        JLabel label3=new JLabel("供货联系人电话");
        JLabel label4=new JLabel("供货联系地址");
        JLabel label5=new JLabel("备注");
        JLabel label6=new JLabel("供货单位简码");
        JLabel label7=new JLabel("供货单位编码");
        JLabel label8=new JLabel("该供货商经营范围");

        JTextField text1=new JTextField();
        JTextField text2=new JTextField();
        JTextField text3=new JTextField();
        JTextField text4=new JTextField();
        JTextField text5=new JTextField();
        JTextField text6=new JTextField();
        JTextField text7=new JTextField();
        JTextField text8=new JTextField();

        JButton buttonok =new JButton("确定");
        JButton buttokexit=new JButton("重置");

        GroupLayout groupLayout2=new GroupLayout(panel1);
        GroupLayout.SequentialGroup hgroup2=groupLayout2.createSequentialGroup();
        hgroup2.addContainerGap(1,5);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label5,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label6,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(label8,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(buttonok,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(1,5);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(text1,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text2,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text3,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text4,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text5,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text6,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text7,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text8,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(buttokexit,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));

        // 此处是被放弃的布局 因为很丑 原来是4 和 7
        //hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(labl4,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(label7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        //hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(text4,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE).addComponent(text7,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE));


        GroupLayout.SequentialGroup vgroup2=groupLayout2.createSequentialGroup();
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label5,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text5,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label6,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text6,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(label8,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text8,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(buttonok,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(buttokexit,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setHorizontalGroup(hgroup2);
        groupLayout2.setVerticalGroup(vgroup2);
        panel1.setLayout(groupLayout2);







        GroupLayout groupLayout1=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=groupLayout1.createSequentialGroup();
        hgroup.addGroup(groupLayout1.createParallelGroup().addComponent(panel1,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgroup=groupLayout1.createSequentialGroup();
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(panel1,GroupLayout.DEFAULT_SIZE,800,GroupLayout.PREFERRED_SIZE));
        groupLayout1.setVerticalGroup(vgroup);
        groupLayout1.setHorizontalGroup(hgroup);
        this.setLayout(groupLayout1);


        buttonok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(text1.getText().toString().equals("")||text2.getText().toString().equals("")||text3.getText().toString().equals("")||text4.getText().toString().equals("")||text5.getText().toString().equals("")||text6.getText().toString().equals("")||text7.getText().toString().equals("")||text8.getText().toString().equals("")){
                    JOptionPane.showMessageDialog(null,
                            "请检查数据是否填写完整",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text1.getText().length()<3||text1.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "供货单位名称长度不能小于3或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text2.getText().length()<2||text2.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "供货联系人长度不能小于2或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text3.getText().length()<6||text3.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "供货联系人电话长度不能小于6或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text4.getText().length()<3||text4.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "供货地址长度不能小于3或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }

                else if(text6.getText().length()<3||text6.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "生产单位简码长度不能小于3或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text7.getText().length()<3||text7.getText().length()>16){
                    JOptionPane.showMessageDialog(null,
                            "供货单位编码长度不能小于3或者大于16",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else if(text8.getText().length()<3||text8.getText().length()>36){
                    JOptionPane.showMessageDialog(null,
                            "供货商范围长度不能小于6或者大于36",
                            "info",
                            INFORMATION_MESSAGE);
                }

                else{
                    //添加所有数据
                    Map<String,Object> map=new HashMap<String, Object>();
                    //随机生成ID
                    int random= (int) ((Math.random()*10000)+Math.random()*101010);
                    map.put("complay_id",random);
                    map.put("complay_name",text1.getText().toString());
                    map.put("complay_peo",text2.getText().toString());
                    map.put("complay_peo_call",text3.getText().toString());
                    map.put("complay_address",text4.getText().toString());
                    map.put("complay_forget",text5.getText().toString());
                    map.put("complay_code",text6.getText().toString());
                    map.put("complay_encode",text7.getText().toString());
                    map.put("complay_sell",text8.getText().toString());
                    complays.insertComplay(map);
                    //执行此按钮的点击事件
                    buttokexit.doClick();
                }
            }
        });




        //清空信息

        buttokexit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                text1.setText("");
                text2.setText("");
                text3.setText("");
                text4.setText("");
                text5.setText("");
                text6.setText("");
                text7.setText("");
                text8.setText("");
            }
        });
    }
}
