package XR.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.sql.SQLException;
import java.util.Map;

public class Manager extends JPanel {
    private String account="account";
    private String produce="produce";
    private String complays="complay";
    private String midirproduces="midirproduce";
    private String midirrooms="midirroom";
    private String midirfoces="midirfoce";
    private Map mapinfo;

    JPanel content;
    MainFrame contenner;

    public Manager(MainFrame mainFrame, Map map){
        this.mapinfo=map;
        this.contenner=mainFrame;
        content =new JPanel();
        content.setLayout(new CardLayout());
        this.setName("Manager");
        this.setLayout(new BorderLayout());

        this.addComponentListener(new ComponentListener() {
            @Override
            public void componentResized(ComponentEvent e) {
                try {
                    createUI();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                    System.out.println(throwables.toString());
                }
            }
            @Override
            public void componentMoved(ComponentEvent e) {

            }
            @Override
            public void componentShown(ComponentEvent e) {

            }
            @Override
            public void componentHidden(ComponentEvent e) {

            }
        });
    }

    public void createUI() throws SQLException {

        //banner区域
        BannerPanel bannerPanel=new BannerPanel();
        this.add(bannerPanel,BorderLayout.NORTH);
        //导航栏区域
        Navgiter navgiter=new Navgiter(this.contenner,Manager.this);
        this.add(navgiter,BorderLayout.WEST);
        //中间核心内容区域

        //账号类型界面
        JTabbedPane tabbedPane=new JTabbedPane();
        tabbedPane.setName(account);
        content.add(tabbedPane,tabbedPane.getName());
        //主页
        AcountPanel acountPanel=new AcountPanel();
        tabbedPane.addTab("系统账号管理",acountPanel);
        //添加用户
        Addcount addcount=new Addcount();
        tabbedPane.addTab("账号添加",addcount);
        //删除用户
        DeleteAccount deleteAccount=new DeleteAccount();
        tabbedPane.addTab("删除已有账号",deleteAccount);
        //浏览账户
        SeeAcountAndEdit seeAcountAndEdit=new SeeAcountAndEdit();
        tabbedPane.addTab("浏览或修改账号",seeAcountAndEdit);

        //修改密码
        EditPass editPass=new EditPass(this.mapinfo);
        tabbedPane.addTab("修改密码",editPass);

        //这里是生产单位区域
        JTabbedPane tableproduce=new JTabbedPane();
        tableproduce.setName(produce);
        content.add(tableproduce,tableproduce.getName());
        InsetProduce insetProduce=new InsetProduce();
        tableproduce.addTab("添加新的生产资料",insetProduce);
        DeleteProduce deleteProduce=new DeleteProduce();
        tableproduce.addTab("删除生产资料",deleteProduce);
        SeeEditProduce seeEditProduce=new SeeEditProduce();
        tableproduce.addTab("浏览或修改生产资料",seeEditProduce);

        //这里是供货单位
        JTabbedPane complay=new JTabbedPane();
        complay.setName(complays);
        content.add(complay,complay.getName());
        Complay complay1=new Complay();
        complay.addTab("供货单位",complay1);
        DeleteComplay deleteComplay=new DeleteComplay();
        complay.addTab("删除供应商信息",deleteComplay);
        SeeComplay complay2=new SeeComplay();
        complay.addTab("浏览供应商信息",complay2);

        //药品信息
        JTabbedPane midirproduce=new JTabbedPane();
        midirproduce.setName(midirproduces);
        content.add(midirproduce,midirproduce.getName());
        Midirproduce overproduce1=new Midirproduce();
        midirproduce.addTab("添加药品",overproduce1);
        MidirSeeAndDeletAndEdit midirSeeAndDeletAndEdit=new MidirSeeAndDeletAndEdit();
        midirproduce.addTab("药品信息",midirSeeAndDeletAndEdit);

        //药房信息
        JTabbedPane midirproduceRoom=new JTabbedPane();
        midirproduceRoom.setName(midirrooms);
        content.add(midirproduceRoom,midirproduceRoom.getName());
        MidirproduceRooms midder=new MidirproduceRooms();
        midirproduceRoom.addTab("添加药房",midder);
        MidiroomSeeAndDeleteAndEdit midiroomSeeAndDeleteAndEdit=new MidiroomSeeAndDeleteAndEdit();
        midirproduceRoom.addTab("药房信息",midiroomSeeAndDeleteAndEdit);

        //药品分类
        JTabbedPane force=new JTabbedPane();
        force.setName(midirfoces);
        content.add(force,force.getName());
        Midirforce midirforce=new Midirforce();
        force.addTab("添加药品分类",midirforce);
        MidirFoceSDE midirFoceSDE=new MidirFoceSDE();
        force.addTab("药品分类信息",midirFoceSDE);


        //这里是内容区域添加
        this.add(content,BorderLayout.CENTER);
    }

    public void Switchtable(String name){
        CardLayout card=(CardLayout)content.getLayout();
        card.show(content,name);
    }
}
