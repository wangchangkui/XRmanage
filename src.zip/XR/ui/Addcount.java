package XR.ui;

import XR.Model.Manager;
import XR.Model.UserModel;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Addcount extends JPanel {


    public Addcount() throws SQLException {
        UserModel userModel=new UserModel();
        //顶部区域
        JPanel jPanel=new JPanel();
        jPanel.setBorder(new TitledBorder(" 添 加 账 号:"));
        JLabel labelname=new JLabel(" 账 号:");
        JLabel labelpass=new JLabel(" 密 码:");
        JLabel labelpass2=new JLabel(" 确 认 密 码：");
        JLabel labelmaneger=new JLabel(" 管 理 等 级:");
        JButton buttonok=new JButton("注册");
        JButton buttonexit=new JButton("重置");
        JComboBox jcom=new JComboBox();

        jcom.addItem("请选择管理等级");
        AcountPanel acountPanel=new AcountPanel();
        jcom=acountPanel.EditBox(jcom);



        JTextField username=new JTextField();
        JPasswordField password=new JPasswordField();
        JPasswordField repassword=new JPasswordField();


        GroupLayout groupLayout1=new GroupLayout(jPanel);
        GroupLayout.SequentialGroup vgroup=groupLayout1.createSequentialGroup();
        GroupLayout.SequentialGroup hgroup=groupLayout1.createSequentialGroup();

        //高
        vgroup.addContainerGap(10,30);
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(labelname,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE)
                .addComponent(username,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup.addContainerGap(10,30);
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(labelmaneger,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE)
                .addComponent(jcom,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup.addContainerGap(10,30);
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(labelpass,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE)
                .addComponent(password,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup.addContainerGap(10,30);
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(labelpass2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE)
                .addComponent(repassword,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup.addContainerGap(10,30);
        vgroup.addGroup(groupLayout1.createParallelGroup().addComponent(buttonok,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE)
                .addComponent(buttonexit,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));



        //宽
        hgroup.addGroup(groupLayout1.createParallelGroup()
                .addComponent(labelname,GroupLayout.DEFAULT_SIZE,50,GroupLayout.PREFERRED_SIZE)
                .addComponent(labelmaneger,GroupLayout.DEFAULT_SIZE,50,GroupLayout.PREFERRED_SIZE)
                .addComponent(labelpass,GroupLayout.DEFAULT_SIZE,50,GroupLayout.PREFERRED_SIZE)
                .addComponent(labelpass2,GroupLayout.DEFAULT_SIZE,50,GroupLayout.PREFERRED_SIZE)
                .addComponent(buttonok,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE)
                );
        hgroup.addGroup(groupLayout1.createParallelGroup()
                .addComponent(username,GroupLayout.DEFAULT_SIZE,150,GroupLayout.PREFERRED_SIZE)
                .addComponent(jcom,GroupLayout.DEFAULT_SIZE,150,GroupLayout.PREFERRED_SIZE)
                .addComponent(password,GroupLayout.DEFAULT_SIZE,150,GroupLayout.PREFERRED_SIZE)
                .addComponent(repassword,GroupLayout.DEFAULT_SIZE,150,GroupLayout.PREFERRED_SIZE)
                .addComponent(buttonexit,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));

        groupLayout1.setHorizontalGroup(hgroup);
        groupLayout1.setVerticalGroup(vgroup);
        jPanel.setLayout(groupLayout1);


        //底部区域
        JPanel footer=new JPanel();
        footer.setBorder(new TitledBorder("注册账号提示"));
        JLabel tip1=new JLabel("账号不能少于6位且不能大于12位");
        tip1.setForeground(Color.cyan);
        JLabel tip2=new JLabel("密码不能少于6位且大于13位");
        tip2.setForeground(Color.orange);
        JLabel tip3=new JLabel("如果未选管理员等级默认是普通管理员");
        tip3.setForeground(Color.red);
        GroupLayout groupLayout3=new GroupLayout(footer);
        GroupLayout.SequentialGroup hgroup3=groupLayout3.createSequentialGroup();
        hgroup3.addContainerGap(10,30);
        hgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tip1).addComponent(tip2).addComponent(tip3));
        GroupLayout.SequentialGroup vgroup3=groupLayout3.createSequentialGroup();
        vgroup3.addContainerGap(10,30);
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tip1));
        vgroup3.addContainerGap(10,30);
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tip2));
        vgroup3.addContainerGap(10,30);
        vgroup3.addGroup(groupLayout3.createParallelGroup().addComponent(tip3));
        groupLayout3.setVerticalGroup(vgroup3);
        groupLayout3.setHorizontalGroup(hgroup3);
        footer.setLayout(groupLayout3);


        //整个面板区域
        GroupLayout groupLayout2=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup2=groupLayout2.createSequentialGroup();
        GroupLayout.SequentialGroup vgroup2=groupLayout2.createSequentialGroup();
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(jPanel,GroupLayout.DEFAULT_SIZE,1000,GroupLayout.PREFERRED_SIZE).addComponent(footer,GroupLayout.DEFAULT_SIZE,1000,GroupLayout.PREFERRED_SIZE));
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(jPanel,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE));
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(footer,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setHorizontalGroup(hgroup2);
        groupLayout2.setVerticalGroup(vgroup2);
        this.setLayout(groupLayout2);






        /**
         * 此处开始是事件处理
         * */

        JComboBox finalJcom = jcom;
        repassword.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(username.equals("")|| finalJcom.getSelectedItem().toString().equals("请选择管理等级")||password.equals("")){
                    JOptionPane.showMessageDialog(null,
                            "请检查是否已经填完整或者已选择相关数据",
                            "INFO",
                            INFORMATION_MESSAGE);
                }
            }
        });
        JComboBox finalJcom1 = jcom;
        buttonok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String pass=password.getText().toString();
                String repass=repassword.getText().toString();
                if(!pass.equals(repass)){
                    JOptionPane.showMessageDialog(null,
                            "两次密码不一致",
                            "INFO",
                            INFORMATION_MESSAGE);
                }
                else{
                    //调用数据库 查询这个名称是不是已经被使用了
                    int s=userModel.NameExit(username.getText().toString());
                    if(s==1){
                        //添加数据
                        try {
                            Manager manager=new Manager();
                            String usernames=username.getText().toString();
                            String passwords=password.getText().toString();
                            String flag=manager.flag(finalJcom1.getSelectedItem().toString());
                            String flagName=finalJcom1.getSelectedItem().toString();
                            userModel.insert(usernames,passwords,flag,flagName);
                            //插入完成之后将文本设置成空
                            username.setText("");
                            password.setText("");
                            repassword.setText("");

                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                        }

                    }
                    else{
                        //删除文本框
                        username.setText("");
                        JOptionPane.showMessageDialog(null,
                                "这个账户已经被使用",
                                "INFO",
                                INFORMATION_MESSAGE);
                    }
                }
            }
        });
    }
}
