package XR.ui;

import javax.swing.*;
import java.awt.*;

public class ContentPlanel extends JPanel {
    private static final long serialVersionUID = 1L;
    public ContentPlanel() {

    }
    public Image getImage(){
        return Toolkit.getDefaultToolkit().getImage("D:/javauml/recose/image/1.jpg");
    }
    public void paintComponent(Graphics g){
        Graphics2D g2d=(Graphics2D)g;
        g2d.drawImage(getImage(),0,0,this);
    }
}
