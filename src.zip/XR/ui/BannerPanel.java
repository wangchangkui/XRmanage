package XR.ui;


import javax.swing.*;
import java.awt.*;

public class BannerPanel extends JPanel {
    public  static final long serialVersionUid=1L;
    public BannerPanel() {
        this.setPreferredSize(new Dimension(0,100));
        this.setLayout(null);
        HeaderPanel headerPanel=new HeaderPanel();
        ContentPlanel contentPlanel=new ContentPlanel();
        Right right=new Right();
        headerPanel.setBounds(0,0,200,100);
        contentPlanel.setBounds(200,0,800,100);
        right.setBounds(1000,0,200,100);
        this.add(headerPanel);
        this.add(contentPlanel);
        this.add(right);
    }
}
