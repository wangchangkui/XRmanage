package XR.ui;

import XR.Model.UserModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class EditPass extends JPanel {
    public EditPass(Map map) {
        //底部
        JPanel top=new JPanel();
        JLabel lbl1=new JLabel("输入当前密码:");
        JLabel lbl2=new JLabel("输入新的密码:");
        JLabel lab3=new JLabel("确认新的密码:");
        JTextField textName=new JTextField();
        JTextField textID=new JTextField();
        JTextField cone=new JTextField();
        lbl2.setForeground(new Color(3,169,244));
        JButton button=new JButton("修改");

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String pass1=textName.getText().toString();  //修改密码
                String pass3=textID.getText().toString();    //原密码
                String pass2=cone.getText().toString();      //确认密码
                String password=(String)map.get("password");

                if ("".equals(pass3)||"".equals(pass1)||"".equals(pass2)){
                    JOptionPane.showMessageDialog(null,
                            "请检查输入框是否有值未输入",
                            "修改信息",
                            INFORMATION_MESSAGE);
                }
                else if(!pass1.equals(pass2)){
                    JOptionPane.showMessageDialog(null,
                            "你的新输入两次密码不正确",
                            "修改信息",
                            INFORMATION_MESSAGE);
                }


                else if(!pass3.equals(password)){
                    JOptionPane.showMessageDialog(null,
                            "原来的密码不正确",
                            "修改信息",
                            INFORMATION_MESSAGE);
                }
                else{
                    UserModel userModel=new UserModel();
                    String Username= (String) map.get("Username");
                    Boolean rs= null;

                    //数据库异常处理
                    try {
                        rs = userModel.EditPassword(textName.getText().toString(),cone.getText(),textName.getText().toString(),Username);
                    } catch (SQLException throwables) {
                        System.out.println(throwables.toString());
                        throwables.printStackTrace();
                    }
                    if(rs){
                        textID.setText("");
                        textName.setText("");
                        cone.setText("");
                        JOptionPane.showMessageDialog(null,
                                "修改成功",
                                "修改信息",
                                INFORMATION_MESSAGE);
                    }
                    else{
                        JOptionPane.showMessageDialog(null,
                                "修改失败,联系管理员",
                                "修改信息",
                                INFORMATION_MESSAGE);
                    }
                }
            }
        });
        /*
         * 这是第一个区域
         * */
        //垂直
        GroupLayout groupLayout1=new GroupLayout(top);
        GroupLayout.SequentialGroup hg=groupLayout1.createSequentialGroup();
        hg.addContainerGap(10,10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lbl2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,10);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(textID,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE).addComponent(textName,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE).addComponent(cone,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,10);

        //水平
        GroupLayout.SequentialGroup vg=groupLayout1.createSequentialGroup();
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(textID, GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(textName,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lab3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(cone,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout1.setVerticalGroup(vg);
        groupLayout1.setHorizontalGroup(hg);
        top.setLayout(groupLayout1);

        //主要界面
        GroupLayout group=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=group.createSequentialGroup();
        hgroup.addGroup(group.createParallelGroup()
                .addComponent(top,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgropu=group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(top,GroupLayout.PREFERRED_SIZE,800,GroupLayout.PREFERRED_SIZE));
        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);
    }
}
