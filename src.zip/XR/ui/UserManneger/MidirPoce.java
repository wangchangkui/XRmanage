package XR.ui.UserManneger;

import XR.Model.Drugs_In;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class MidirPoce extends JPanel {
    public MidirPoce() throws SQLException {
        //浏览表

        Drugs_In drugs_in=new Drugs_In();

        JPanel seePanel=new JPanel();
        seePanel.setBorder(new TitledBorder("申购药品单（双击修改）"));

        
        JTable tables=new JTable();

        DefaultTableModel tableModel=(DefaultTableModel)tables.getModel();

        tableModel.addColumn("药品编号");
        tableModel.addColumn("药品名称");
        tableModel.addColumn("生产商");
        tableModel.addColumn("供货商");
        tableModel.addColumn("药品数量");
        tableModel.addColumn("药品有效期（天）");
        tableModel.addColumn("入库时间");
        tableModel.addColumn("药品生产时间");
        tableModel.addColumn("价格");


        List<Map<String,Object>> list= drugs_in.selectAll();
        Map<String,Object> map=null;


        //此时数据库的数据保存到这个obj中
        Object[][] obj=new Object[list.size()][];

        for(int i=0;i<list.size();i++){
            map=list.get(i);
            obj[i]=new Object[]{map.get("drugs_id"),map.get("drugs_name"),map.get("drugs_pro"),map.get("drugs_peo"),map.get("drugs_nums"),map.get("drugs_day"),map.get("drugs_time"),map.get("drugs_pro_time"),map.get("drugs_price")};
            tableModel.addRow(obj[i]);
        }

        final String[] ID = {""};
        tables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x=tables.getSelectedRow();
                int y=tables.getSelectedColumn();
                if(x!=-1&&y!=-1){
                    if(y==0){
                        JOptionPane.showMessageDialog(null,
                                "所选列是不能被修改的",
                                "Info",
                                INFORMATION_MESSAGE);
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                    else{
                        while (y>0){
                            y--;
                        }
                        ID[0] =tableModel.getValueAt(x,y).toString();
                        System.out.println(ID[0]);
                    }
                }
            }
        });





        List<Map<String, String>> changelist=new ArrayList<Map<String, String>>();
        final Map<String, String>[] chagemap = new Map[]{null};

        tableModel.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int i=tables.getSelectedRow();
                int j=tables.getSelectedColumn();
                if(i!=-1&&j!=-1){
                    chagemap[0] =new HashMap<String, String>();
                    chagemap[0].put("drugs_id",ID[0]);
                    chagemap[0].put("drugs_name",tableModel.getValueAt(i,1).toString());
                    chagemap[0].put("drugs_pro",tableModel.getValueAt(i,2).toString());
                    chagemap[0].put("drugs_peo",tableModel.getValueAt(i,3).toString());
                    chagemap[0].put("drugs_nums",tableModel.getValueAt(i,4).toString());
                    chagemap[0].put("drugs_day",tableModel.getValueAt(i,5).toString());
                    chagemap[0].put("drugs_time",tableModel.getValueAt(i,6).toString());
                    chagemap[0].put("drugs_pro_time",tableModel.getValueAt(i,7).toString());
                    chagemap[0].put("drugs_price",tableModel.getValueAt(i,8).toString());
                    changelist.add(chagemap[0]);
                }
            }
        });


        //循环检测数据

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    try {
                        Thread.sleep(3000);

                        int tableCount=tableModel.getRowCount();
                        int rowCount=drugs_in.countAll();
                        if(tableCount!=rowCount){
                            int i=0;
                            while (i < tableModel.getRowCount()){
                                tableModel.removeRow(i);
                            }

                            List<Map<String, Object>> list=drugs_in.selectAll();
                            Map<String, Object> map;

                            for (int s = 0; s < list.size(); s++) {
                                map = list.get(s);
                                Object[] obj = new String[]{map.get("drugs_id").toString(),map.get("drugs_name").toString(),map.get("drugs_pro").toString(),map.get("drugs_peo").toString(),map.get("drugs_nums").toString(),map.get("drugs_day").toString(),map.get("drugs_time").toString(),map.get("drugs_pro_time").toString(),map.get("drugs_price").toString()};
                                tableModel.addRow(obj);
                                changelist.clear();
                            }
                        }


                    } catch (InterruptedException | SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();









        tables.setShowGrid(true);
        tables.setRowHeight(30);
        tables.setGridColor(new Color(3,169,244));
        tables.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.getTableHeader().setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        //滑动
        tables.setPreferredScrollableViewportSize(new Dimension(10,500));
        GroupLayout groupLayout=new GroupLayout(seePanel);
        GroupLayout.SequentialGroup hg=groupLayout.createSequentialGroup();
        hg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,900,GroupLayout.PREFERRED_SIZE).addComponent(tables,GroupLayout.DEFAULT_SIZE,900,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vg=groupLayout.createSequentialGroup();
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables,GroupLayout.DEFAULT_SIZE,600,GroupLayout.PREFERRED_SIZE));
        groupLayout.setHorizontalGroup(hg);
        groupLayout.setVerticalGroup(vg);
        seePanel.setLayout(groupLayout);



        //底部
        JPanel infos=new JPanel();
        JButton editButton=new JButton("保存修改");
        GroupLayout groupLayout2=new GroupLayout(infos);
        GroupLayout.SequentialGroup vgroups=groupLayout2.createSequentialGroup();
        vgroups.addContainerGap(10,30);
        vgroups.addGroup(groupLayout2.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup hgroups=groupLayout2.createSequentialGroup();
        hgroups.addContainerGap(1,2);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        hgroups.addContainerGap(10,30);
        groupLayout2.setVerticalGroup(vgroups);
        groupLayout2.setHorizontalGroup(hgroups);
        infos.setLayout(groupLayout2);



        //主要界面
        GroupLayout group=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=group.createSequentialGroup();
        hgroup.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE)
                .addComponent(infos,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgropu=group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,600,GroupLayout.PREFERRED_SIZE));
        vgropu.addGroup(group.createParallelGroup().addComponent(infos,GroupLayout.PREFERRED_SIZE,200,GroupLayout.PREFERRED_SIZE));
        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //1.获取chagelist的长度

                int count=0;
                for(int i=0;i<changelist.size();i++){
                    Map<String, String> map=changelist.get(i);
                    int ok= 0;
                    try {
                        ok = drugs_in.update(map);
                        if(ok==1){
                            count++;
                        }
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }

                }
                JOptionPane.showMessageDialog(null,
                        "更新成功,共更新'"+count+"'次数据",
                        "数据库信息",
                        INFORMATION_MESSAGE);

                changelist.clear();
            }
        });
    }
}
