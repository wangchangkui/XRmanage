package XR.ui.UserManneger;

import XR.Model.Drugs;
import XR.Model.Drugs_Book;
import XR.Model.Drugs_In;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class MidirIN extends JPanel {
    public MidirIN() throws SQLException {

        Drugs_In drugs_in=new Drugs_In();
        Drugs_Book drugs_book=new Drugs_Book();
        JPanel jPanel=new JPanel();
        jPanel.setBorder(new TitledBorder("药品基本信息"));
        JLabel lab1=new JLabel("药品名称");
        JLabel lab2=new JLabel("药品生产商");
        JLabel lab3=new JLabel("供货商");
        JLabel lab4=new JLabel("入库数量");
        JLabel lab5=new JLabel("药品有效期");
        JLabel lab6=new JLabel("入库时间");
        JLabel lab7=new JLabel("药品生产时间");
        JLabel lab8=new JLabel("入库价格");

        JComboBox box1=getAllDrug_name();
        JComboBox box2=getAllDrug_drugs_address();
        JComboBox box3=getAllDrug_drugs_peo();
        JTextField text1=new JTextField();
        JTextField text2=new JTextField();
        JTextField text3=new JTextField();
        JTextField text4=new JTextField();
        JTextField text5=new JTextField();

        JButton button1=new JButton("添加");
        JButton button2=new JButton("重置");


        //添加药品信息
        GroupLayout groupLayout2=new GroupLayout(jPanel);
        GroupLayout.SequentialGroup hgroup2=groupLayout2.createSequentialGroup();
        hgroup2.addContainerGap(1,1);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(lab1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(10,20);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(box1,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE).addComponent(text3,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE).addComponent(text5,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(10,20);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(lab2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab5,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab8,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(10,20);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(box2,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE).addComponent(text2,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE).addComponent(text4,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(10,20);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(lab3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab6,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button1,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE));
        hgroup2.addContainerGap(10,20);
        hgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(box3,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE).addComponent(text1,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE).addComponent(button2,GroupLayout.DEFAULT_SIZE,200,GroupLayout.PREFERRED_SIZE));

        GroupLayout.SequentialGroup vgroup2=groupLayout2.createSequentialGroup();
        vgroup2.addContainerGap(10,20);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(lab1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(box1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(box2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(box3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(lab4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab5,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab6,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vgroup2.addContainerGap(10,30);
        vgroup2.addGroup(groupLayout2.createParallelGroup().addComponent(lab7,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text5,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab8,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(text4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));



        groupLayout2.setHorizontalGroup(hgroup2);
        groupLayout2.setVerticalGroup(vgroup2);
        jPanel.setLayout(groupLayout2);


        //浏览表
        JPanel seePanel=new JPanel();
        seePanel.setBorder(new TitledBorder("申购药品单（双击修改）"));

        JTable tables=new JTable();
        DefaultTableModel tableModel=(DefaultTableModel)tables.getModel();
        tableModel.addColumn("药品编号");
        tableModel.addColumn("药品名称");
        tableModel.addColumn("生产商");
        tableModel.addColumn("供货商");
        tableModel.addColumn("药品数量");
        tableModel.addColumn("药品有效期（天）");
        tableModel.addColumn("入库时间");
        tableModel.addColumn("药品生产时间");
        tableModel.addColumn("价格");


        List<Map<String,Object>> list= drugs_in.selectAll();
        Map<String,Object> map=null;


        //此时数据库的数据保存到这个obj中
        Object[][] obj=new Object[list.size()][];

        for(int i=0;i<list.size();i++){
            map=list.get(i);
            obj[i]=new Object[]{map.get("drugs_id"),map.get("drugs_name"),map.get("drugs_pro"),map.get("drugs_peo"),map.get("drugs_nums"),map.get("drugs_day"),map.get("drugs_time"),map.get("drugs_pro_time"),map.get("drugs_price")};
            tableModel.addRow(obj[i]);
        }


        final String[] ID = {""};
        tables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x=tables.getSelectedRow();
                int y=tables.getSelectedColumn();
                if(x!=-1&&y!=-1){
                    if(y==0){
                        JOptionPane.showMessageDialog(null,
                                "所选列是不能被修改的",
                                "Info",
                                INFORMATION_MESSAGE);
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                    else{
                        while (y>0){
                            y--;
                        }
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                }
            }
        });

        List<Map<String, String>> changelist=new ArrayList<Map<String, String>>();
        final Map<String, String>[] chagemap = new Map[]{null};
        tableModel.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {

                try {
                    int i=tables.getSelectedRow();
                    int j=tables.getSelectedColumn();
                    if(i!=-1&&j!=-1){
                        chagemap[0] =new HashMap<String, String>();
                        chagemap[0].put("drugs_id",ID[0]);
                        chagemap[0].put("drugs_name",tableModel.getValueAt(i,1).toString());
                        chagemap[0].put("drugs_pro",tableModel.getValueAt(i,2).toString());
                        chagemap[0].put("drugs_peo",tableModel.getValueAt(i,3).toString());
                        chagemap[0].put("drugs_nums",tableModel.getValueAt(i,4).toString());
                        chagemap[0].put("drugs_day",tableModel.getValueAt(i,5).toString());
                        chagemap[0].put("drugs_time",tableModel.getValueAt(i,6).toString());
                        chagemap[0].put("drugs_pro_time",tableModel.getValueAt(i,7).toString());
                        chagemap[0].put("drugs_price",tableModel.getValueAt(i,8).toString());
                        changelist.add(chagemap[0]);
                    }
                }
                catch (Exception e1){

                }

            }
        });



        tables.setShowGrid(true);
        tables.setRowHeight(30);
        tables.setGridColor(new Color(3,169,244));
        tables.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.getTableHeader().setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.setPreferredScrollableViewportSize(new Dimension(10,500));


        GroupLayout groupLayout=new GroupLayout(seePanel);
        GroupLayout.SequentialGroup hg=groupLayout.createSequentialGroup();
        hg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE).addComponent(tables,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vg=groupLayout.createSequentialGroup();
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables,GroupLayout.DEFAULT_SIZE,600,GroupLayout.PREFERRED_SIZE));
        groupLayout.setHorizontalGroup(hg);
        groupLayout.setVerticalGroup(vg);
        seePanel.setLayout(groupLayout);





        //底部
        JPanel infos=new JPanel();
        JButton button=new JButton("删除");
        JButton editButton=new JButton("保存修改");
        JButton exitButton=new JButton("放弃修改");
        GroupLayout groupLayout3=new GroupLayout(infos);
        GroupLayout.SequentialGroup vgroups3=groupLayout3.createSequentialGroup();
        vgroups3.addContainerGap(10,30);
        vgroups3.addGroup(groupLayout3.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(exitButton,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup hgroups4=groupLayout3.createSequentialGroup();
        hgroups4.addContainerGap(1,2);
        hgroups4.addGroup(groupLayout3.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        hgroups4.addContainerGap(10,30);
        hgroups4.addGroup(groupLayout3.createParallelGroup().addComponent(exitButton,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        hgroups4.addContainerGap(10,30);
        hgroups4.addGroup(groupLayout3.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        groupLayout3.setVerticalGroup(vgroups3);
        groupLayout3.setHorizontalGroup(hgroups4);
        infos.setLayout(groupLayout3);

        GroupLayout groupLayout1=new GroupLayout(this);
        GroupLayout.SequentialGroup vgropu1=groupLayout1.createSequentialGroup();
        vgropu1.addGroup(groupLayout1.createParallelGroup().addComponent(jPanel,GroupLayout.DEFAULT_SIZE,250,GroupLayout.PREFERRED_SIZE));
        vgropu1.addGroup(groupLayout1.createParallelGroup().addComponent(seePanel,GroupLayout.DEFAULT_SIZE,400,GroupLayout.PREFERRED_SIZE));
        vgropu1.addGroup(groupLayout1.createParallelGroup().addComponent(infos,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));

        GroupLayout.SequentialGroup hgropu1=groupLayout1.createSequentialGroup();
        hgropu1.addGroup(groupLayout1.createParallelGroup().addComponent(jPanel,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE).addComponent(seePanel,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE).addComponent(infos,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        groupLayout1.setVerticalGroup(vgropu1);
        groupLayout1.setHorizontalGroup(hgropu1);
        this.setLayout(groupLayout1);


        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(text1.getText().toString().equals("")||text2.getText().toString().equals("")||text3.getText().toString().equals("")||text4.getText().toString().equals("")||text5.getText().toString().equals("")||text1.getText().toString().equals("日期格式：2020-12-9")||text5.getText().toString().equals("日期格式：2020-12-9")){
                    JOptionPane.showMessageDialog(null,
                            "请将数据填写完整",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else{
                    //添加所有数据
                    Map<String,Object> map=new HashMap<String, Object>();
                    int random= (int) ((Math.random()*10000)+Math.random()*101010);
                    map.put("drugs_id",random);
                    map.put("drugs_name",box1.getSelectedItem().toString());
                    map.put("drugs_pro",box2.getSelectedItem().toString());
                    map.put("drugs_peo",box3.getSelectedItem().toString());
                    map.put("drugs_nums",text3.getText().toString());
                    map.put("drugs_day",text2.getText().toString());
                    map.put("drugs_time",text5.getText().toString());
                    map.put("drugs_pro_time",text1.getText().toString());
                    map.put("drugs_price",text4.getText().toString());

                    //业务单据的审核
                    Map<String,Object> map2=new HashMap<String, Object>();
                    int random2= (int) ((Math.random()*10000)+Math.random()*101010);
                    map2.put("book_id",random2);
                    map2.put("content",box1.getSelectedItem().toString()+"入库"+text3.getText().toString()+"盒，每盒"+Integer.parseInt(text4.getText().toString())+"元，共计"+Integer.parseInt(text4.getText().toString())*Integer.parseInt(text3.getText().toString())+"元");

                    try {
                        drugs_in.insert(map);
                        drugs_book.insert(map2);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }

                    //此处记得添加数据到表格
                    Object[] obj=new Object[]{map.get("drugs_id"),map.get("drugs_name"),map.get("drugs_pro"),map.get("drugs_peo"),map.get("drugs_nums"),map.get("drugs_day"),map.get("drugs_time"),map.get("drugs_pro_time"),map.get("drugs_price")};
                    tableModel.addRow(obj);
                    //清楚添加的数据

                    changelist.clear();
                    button2.doClick();
                }



            }
        });

        text5.setText("日期格式：2020-12-9");
        text5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                text5.setText("");
            }
        });
        text1.setText("日期格式：2020-12-9");
        text1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                text1.setText("");
            }
        });


        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                text1.setText("");
                text2.setText("");
                text3.setText("");
                text4.setText("");
                text5.setText("");
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int count=0;
                for(int i=0;i<changelist.size();i++){
                    Map<String, String> map=changelist.get(i);
                    int ok= 0;
                    try {
                        ok = drugs_in.update(map);
                        if(ok==1){
                            count++;
                        }
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }

                }
                JOptionPane.showMessageDialog(null,
                        "更新成功,共更新'"+count+"'次数据",
                        "数据库信息",
                        INFORMATION_MESSAGE);

                changelist.clear();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,
                        "暂存数据已清除",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                int i=0;
                while (i<tableModel.getRowCount()){
                    tableModel.removeRow(i);
                }

                List<Map<String,Object>> lists= null;
                try {
                    lists = drugs_in.selectAll();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                Map<String,Object> maps=null;
                for(int i1=0;i1< lists.size();i1++){
                    maps=lists.get(i1);
                    Object obj[]=new Object[]{maps.get("drugs_id"),maps.get("drugs_name"),maps.get("drugs_pro"),maps.get("drugs_peo"),maps.get("drugs_nums"),maps.get("drugs_day"),maps.get("drugs_time"),maps.get("drugs_pro_time"),maps.get("drugs_price")};
                    tableModel.addRow(obj);
                }

                changelist.clear();

            }

        });

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    drugs_in.DeletDrug(ID[0]);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                for(int i=0;i<tableModel.getRowCount();i++){
                    if(tableModel.getValueAt(i,0).toString().equals(ID[0].toString())){
                        tableModel.removeRow(i);
                    }
                }
                changelist.clear();
            }
        });





    }


    //获取所有的药品名称
    public JComboBox getAllDrug_name(){
        Object[] items=null;
        Drugs drugs=new Drugs();
        items=drugs.getDrug_name();
        JComboBox jComboBox=new JComboBox(items);
        return jComboBox;
    }

    //获取所有的药品名称
    public JComboBox getAllDrug_drugs_address(){
        Object[] items=null;
        Drugs drugs=new Drugs();
        items=drugs.getDrug_address();
        JComboBox jComboBox=new JComboBox(items);
        return jComboBox;
    }

    //获取所有的药品名称
    public JComboBox getAllDrug_drugs_peo(){
        Object[] items=null;
        Drugs drugs=new Drugs();
        items=drugs.getDrug_peo();
        JComboBox jComboBox=new JComboBox(items);
        return jComboBox;
    }
}
