package XR.ui.UserManneger;

import XR.Model.Drugs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class MidirEnable extends JPanel {
    public MidirEnable() {
//底部
        JPanel top=new JPanel();

        JLabel lbl1=new JLabel("药品编号:");
        JLabel lbl2=new JLabel("药品名称:");
        JLabel lab3=new JLabel("原零售价:");
        JLabel lab4=new JLabel("调整价格:");
        JTextField textName=new JTextField();
        JTextField textID=new JTextField();
        JTextField cone=new JTextField();
        JTextField refos=new JTextField();
        JButton button=new JButton("修改");
        /*
         * 这是第一个区域
         * */
        //垂直
        GroupLayout groupLayout1=new GroupLayout(top);
        GroupLayout.SequentialGroup hg=groupLayout1.createSequentialGroup();
        hg.addContainerGap(10,250);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lbl2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(lab4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button,GroupLayout.DEFAULT_SIZE,100,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,30);
        hg.addGroup(groupLayout1.createParallelGroup().addComponent(textID,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE).addComponent(textName,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE).addComponent(cone,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE).addComponent(refos,GroupLayout.DEFAULT_SIZE,300,GroupLayout.PREFERRED_SIZE));
        hg.addContainerGap(10,30);

        //水平
        GroupLayout.SequentialGroup vg=groupLayout1.createSequentialGroup();
        vg.addContainerGap(10,200);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl1,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(textID, GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lbl2,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(textName,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lab3,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(cone,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(lab4,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(refos,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addContainerGap(10,40);
        vg.addGroup(groupLayout1.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        groupLayout1.setVerticalGroup(vg);
        groupLayout1.setHorizontalGroup(hg);
        top.setLayout(groupLayout1);

        //主要界面
        GroupLayout group=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=group.createSequentialGroup();
        hgroup.addGroup(group.createParallelGroup()
                .addComponent(top,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgropu=group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(top,GroupLayout.PREFERRED_SIZE,800,GroupLayout.PREFERRED_SIZE));
        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);


        Drugs drugs=new Drugs();
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    try {
                        Thread.sleep(1000);

                        if(!(textID.getText().equals("")))
                        {
                            Map<String,Object> map=drugs.selectInfo(textID.getText().toString());

                            if(!map.isEmpty()){
                                textName.setText(map.get("drugs_name").toString());
                                cone.setText(map.get("drugs_price").toString());
                            }
                            else{
                                textName.setText("");
                                cone.setText("");
                            }


                        }


                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();


        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textID.getText().equals("")||textName.getText().equals("")||cone.getText().equals("")||refos.getText().equals("")){
                    JOptionPane.showMessageDialog(null,
                            "请检查数据的完整性",
                            "info",
                            INFORMATION_MESSAGE);
                }
                else{
                    Object[] obj=new Object[]{textID.getText().toString(),refos.getText().toString()};
                    drugs.updatePrice(obj);
                }
            }
        });
    }
}
