package XR.ui.UserManneger;

import XR.ui.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class UserManger extends JPanel {
    private String account="account";
    private String produce="produce";
    private String complays="complay";
    private String midirproduces="midirproduce";
    private String midirrooms="midirroom";
    private String midirfoces="midirfoce";


    private Map map;
    JPanel content;
    MainFrame contenner;

    public UserManger(MainFrame mainFrame,Map map) {
        //此处可以获取map值
        this.map=map;




        this.setName("UserManger");
        this.contenner=mainFrame;
        this.setLayout(new BorderLayout());
        content =new JPanel();
        content.setLayout(new CardLayout());
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                try {
                    CreatUI();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        });
    }
    public void CreatUI() throws SQLException {
        //banner区域
        BannerPanel bannerPanel=new BannerPanel();
        this.add(bannerPanel,BorderLayout.NORTH);
        //导航栏区域
        UserNagtive navgiter=new UserNagtive(this.contenner, UserManger.this);
        this.add(navgiter,BorderLayout.WEST);

        //账号类型界面
        JTabbedPane tabbedPane=new JTabbedPane();
        tabbedPane.setName(account);
        content.add(tabbedPane,tabbedPane.getName());

        //修改密码

        EditPass editPass=new EditPass(this.map);
        tabbedPane.addTab("修改密码",editPass);

        //这里是生产单位区域
        JTabbedPane tableproduce=new JTabbedPane();
        tableproduce.setName(produce);
        content.add(tableproduce,tableproduce.getName());
        MidirPoce insetProduce=new MidirPoce();
        tableproduce.addTab("药品申购单",insetProduce);
        MidirIN deleteProduce=new MidirIN();
        tableproduce.addTab("药品入库单",deleteProduce);
        MidirOUT seeEditProduce=new MidirOUT();
        tableproduce.addTab("药品出库单",seeEditProduce);

        //这里是供货单位
        JTabbedPane complay=new JTabbedPane();
        complay.setName(complays);
        content.add(complay,complay.getName());
        Foceinfo complay1 =new Foceinfo();
        complay.addTab("单据审核",complay1);

        //药品信息
        JTabbedPane midirproduce=new JTabbedPane();
        midirproduce.setName(midirproduces);
        content.add(midirproduce,midirproduce.getName());
        MidirEnable overproduce1=new MidirEnable();
        midirproduce.addTab("药品零售价调整",overproduce1);
        MidirPass midirPass=new MidirPass();
        midirproduce.addTab("过期药品管理",midirPass);

        //药房信息
        JTabbedPane midirproduceRoom=new JTabbedPane();
        midirproduceRoom.setName(midirrooms);
        content.add(midirproduceRoom,midirproduceRoom.getName());
        ProduceRoom midder=new ProduceRoom();
        midirproduceRoom.addTab("库存统计与报表",midder);
        ProdeceFoce produce=new ProdeceFoce();
        midirproduceRoom.addTab("缺货统计与报表",produce);

        //这里是内容区域添加
        this.add(content,BorderLayout.CENTER);
    }

    public void Switchtable(String name){
        CardLayout card=(CardLayout)content.getLayout();
        card.show(content,name);
    }

}
