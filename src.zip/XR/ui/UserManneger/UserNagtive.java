package XR.ui.UserManneger;

import XR.ui.MainFrame;
import XR.userComponet.MenuLable;

import javax.swing.*;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Map;

public class UserNagtive extends JPanel {
    private static final long serialVersionUID = 1L;
    JLabel Lables;
    public UserNagtive(MainFrame mainFram,UserManger userManger) {
        this.setPreferredSize(new Dimension(200,0));
        this.setBorder(new MatteBorder(2,2,2,2,new Color(233,242,255)));
        this.setLayout(null);
        Lables =new UserMenuLable(" 账 号 管 理 ","account",userManger);
        Lables.setBounds(9,21,180,34);
        this.add(Lables);

        Lables =new UserMenuLable(" 业 务 单 据 录 入 ","produce",userManger);
        Lables.setBounds(9,71,180,34);
        this.add(Lables);

        Lables =new UserMenuLable(" 业 务 单 据 审 核 ","complay",userManger);
        Lables.setBounds(9,121,180,34);
        this.add(Lables);

        Lables =new UserMenuLable(" 药 品  管 理 ","midirproduce",userManger);
        Lables.setBounds(9,171,180,34);
        this.add(Lables);

        Lables =new UserMenuLable(" 统计 与 报表 管理 ","midirroom",userManger);
        Lables.setBounds(9,221,180,34);
        this.add(Lables);

        Lables =new MenuLable(" 退 出 系 统 ","exit",null);
        Lables.setBounds(9,271,180,34);
        Lables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Map<String ,String> map=new HashMap<String, String>();
                map.put("flag","0");
                map.put("username","");
                mainFram.switchPanl("LoginUI",map);
                JOptionPane.showMessageDialog(null,"成功退出系统","退出系统",JOptionPane.INFORMATION_MESSAGE);
            }
        });
        this.add(Lables);
    }

    //背景颜色
    public Image getImage(){
        return Toolkit.getDefaultToolkit().getImage("D:/javauml/recose/image/menu.jpg");
    }
    public void paintComponent(Graphics g){
        Graphics2D g2d=(Graphics2D)g;
        g2d.drawImage(getImage(),0,0,this);
    }

}

