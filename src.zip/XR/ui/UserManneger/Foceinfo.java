package XR.ui.UserManneger;

import XR.Model.Drugs_Book;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Foceinfo extends JPanel {
    public Foceinfo() {
        //浏览表
        JPanel seePanel=new JPanel();
        Drugs_Book drugs_book=new Drugs_Book();

        JLabel label1=new JLabel("需要审核的报表单如下:");
        JLabel label2=new JLabel("点击所选行，通过下面的按钮进行审核");
        label2.setForeground(Color.RED);
        seePanel.setBorder(new TitledBorder("数据内容"));

        JTable tables=new JTable();
        DefaultTableModel tableModel=(DefaultTableModel)tables.getModel();
        tableModel.addColumn("单据编号");
        tableModel.addColumn("审核内容");
        tableModel.addColumn("审核状态");

        List<Map<String,Object>> lists= null;
        try {
            lists = drugs_book.selectAll();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        Map<String,Object> maps=null;
        for(int i1=0;i1< lists.size();i1++){
            maps=lists.get(i1);
            Object obj[]=new Object[]{maps.get("book_id"),maps.get("content"),maps.get("flag")};
            tableModel.addRow(obj);
        }


        final String[] ID = {""};
        tables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x=tables.getSelectedRow();
                int y=tables.getSelectedColumn();
                if(x!=-1&&y!=-1){
                    if(y==0){
                        JOptionPane.showMessageDialog(null,
                                "禁止修改此列",
                                "Info",
                                INFORMATION_MESSAGE);
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                    else{
                        while (y!=0){
                            y--;
                        }
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                }

            }
        });




        tables.setShowGrid(true);
        tables.setRowHeight(30);
        tables.setGridColor(new Color(3,169,244));
        tables.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.getTableHeader().setBorder(new EtchedBorder(EtchedBorder.LOWERED));

        //滑动
        tables.setPreferredScrollableViewportSize(new Dimension(10,500));





        GroupLayout groupLayout=new GroupLayout(seePanel);
        GroupLayout.SequentialGroup hg=groupLayout.createSequentialGroup();
        hg.addGroup(groupLayout.createParallelGroup().addComponent(label1).addComponent(label2).addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE).addComponent(tables,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vg=groupLayout.createSequentialGroup();
        vg.addGroup(groupLayout.createParallelGroup().addComponent(label1));
        vg.addGroup(groupLayout.createParallelGroup().addComponent(label2));
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables,GroupLayout.DEFAULT_SIZE,600,GroupLayout.PREFERRED_SIZE));

        groupLayout.setHorizontalGroup(hg);
        groupLayout.setVerticalGroup(vg);
        seePanel.setLayout(groupLayout);



        //底部
        JPanel infos=new JPanel();
        JButton button=new JButton("所选行通过审核");
        JButton editButton=new JButton("所选行未通过审核");
        JButton exitButton=new JButton("删除所选行数据");
        GroupLayout groupLayout2=new GroupLayout(infos);
        GroupLayout.SequentialGroup vgroups=groupLayout2.createSequentialGroup();
        vgroups.addContainerGap(10,30);
        vgroups.addGroup(groupLayout2.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(exitButton,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));

        GroupLayout.SequentialGroup hgroups=groupLayout2.createSequentialGroup();
        hgroups.addContainerGap(1,2);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        hgroups.addContainerGap(10,30);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(exitButton,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        hgroups.addContainerGap(10,30);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setVerticalGroup(vgroups);
        groupLayout2.setHorizontalGroup(hgroups);
        infos.setLayout(groupLayout2);


        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                drugs_book.update(ID[0],"1");

                int i=0;
                while (i<tableModel.getRowCount()){
                    tableModel.removeRow(i);
                }

                List<Map<String,Object>> lists= null;
                try {
                    lists = drugs_book.selectAll();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                Map<String,Object> maps=null;
                for(int i1=0;i1< lists.size();i1++){
                    maps=lists.get(i1);
                    Object obj[]=new Object[]{maps.get("book_id"),maps.get("content"),maps.get("flag")};
                    tableModel.addRow(obj);
                }
            }
        });


        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                drugs_book.update(ID[0],"0");

                int i=0;
                while (i<tableModel.getRowCount()){
                    tableModel.removeRow(i);
                }

                List<Map<String,Object>> lists= null;
                try {
                    lists = drugs_book.selectAll();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                Map<String,Object> maps=null;
                for(int i1=0;i1< lists.size();i1++){
                    maps=lists.get(i1);
                    Object obj[]=new Object[]{maps.get("book_id"),maps.get("content"),maps.get("flag")};
                    tableModel.addRow(obj);
                }
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    drugs_book.DeletDrug(ID[0]);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                int i=0;
                while (i<tableModel.getRowCount()){
                    tableModel.removeRow(i);
                }

                List<Map<String,Object>> lists= null;
                try {
                    lists = drugs_book.selectAll();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                Map<String,Object> maps=null;
                for(int i1=0;i1< lists.size();i1++){
                    maps=lists.get(i1);
                    Object obj[]=new Object[]{maps.get("book_id"),maps.get("content"),maps.get("flag")};
                    tableModel.addRow(obj);
                }
            }
        });


        //主要界面
        GroupLayout group=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=group.createSequentialGroup();
        hgroup.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE)
                .addComponent(infos,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgropu=group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,600,GroupLayout.PREFERRED_SIZE));
        vgropu.addGroup(group.createParallelGroup().addComponent(infos,GroupLayout.PREFERRED_SIZE,200,GroupLayout.PREFERRED_SIZE));
        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);
    }
}
