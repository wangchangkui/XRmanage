package XR.ui.UserManneger;


import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class UserMenuLable extends JLabel {
    private static final long serialVersionUID = 1L;

    public UserMenuLable(String text,String name, UserManger manger) {
        this.setText(text);
        this.setName(name);
        this.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        this.setBorder(new EtchedBorder(EtchedBorder.RAISED));
        this.setOpaque(true);
        Color color = this.getBackground();
        this.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(manger !=null){
                    manger.Switchtable(name);
                }
            }
            @Override
            public void mousePressed(MouseEvent e) {

            }
            @Override
            public void mouseReleased(MouseEvent e) {

            }
            @Override
            public void mouseEntered(MouseEvent e) {
                setBackground(new Color(3,169,244));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                setBackground(color);
            }
        });
    }
}
