package XR.ui.UserManneger;

import XR.Model.Drugs_exit;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class MidirPass extends JPanel {
    public MidirPass(){
        //浏览表
        JPanel seePanel=new JPanel();
        seePanel.setBorder(new TitledBorder("药品过期表"));
        seePanel.setBorder(new TitledBorder("数据内容"));
        Drugs_exit drugs_exit=new Drugs_exit();
        JTable tables=new JTable();
        DefaultTableModel tableModel=(DefaultTableModel)tables.getModel();
        tableModel.addColumn("药品编号");
        tableModel.addColumn("药品名称");
        tableModel.addColumn("药品过期数量");

        List<Map<String,Object>> lists= null;
        try {
            lists = drugs_exit.SelectAllinfo();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        Map<String,Object> maps=null;
        for(int i1=0;i1< lists.size();i1++){
            maps=lists.get(i1);
            Object obj[]=new Object[]{maps.get("drugs_id"),maps.get("drugs_name"),maps.get("drugs_number")};
            tableModel.addRow(obj);
        }

        final String[] ID = {""};
        tables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x=tables.getSelectedRow();
                int y=tables.getSelectedColumn();
                if(x!=-1&&y!=-1){
                    if(y==0){
                        JOptionPane.showMessageDialog(null,
                                "禁止修改此列",
                                "Info",
                                INFORMATION_MESSAGE);
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                    else{
                        while (y!=0){
                            y--;
                        }
                        ID[0] =tableModel.getValueAt(x,y).toString();
                    }
                }

            }
        });


        tables.setShowGrid(true);
        tables.setRowHeight(30);
        tables.setGridColor(new Color(3,169,244));
        tables.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
        tables.getTableHeader().setBorder(new EtchedBorder(EtchedBorder.LOWERED));

        //滑动
        tables.setPreferredScrollableViewportSize(new Dimension(10,500));
        GroupLayout groupLayout=new GroupLayout(seePanel);
        GroupLayout.SequentialGroup hg=groupLayout.createSequentialGroup();
        hg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE).addComponent(tables,GroupLayout.DEFAULT_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vg=groupLayout.createSequentialGroup();
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables.getTableHeader(),GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));
        vg.addGroup(groupLayout.createParallelGroup().addComponent(tables,GroupLayout.DEFAULT_SIZE,600,GroupLayout.PREFERRED_SIZE));

        groupLayout.setHorizontalGroup(hg);
        groupLayout.setVerticalGroup(vg);
        seePanel.setLayout(groupLayout);



        //底部
        JPanel infos=new JPanel();
        JButton button=new JButton("删除所选数据");
        JButton editButton=new JButton("刷新表格");
        GroupLayout groupLayout2=new GroupLayout(infos);
        GroupLayout.SequentialGroup vgroups=groupLayout2.createSequentialGroup();
        vgroups.addContainerGap(10,30);
        vgroups.addGroup(groupLayout2.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE).addComponent(button,GroupLayout.DEFAULT_SIZE,30,GroupLayout.PREFERRED_SIZE));

        GroupLayout.SequentialGroup hgroups=groupLayout2.createSequentialGroup();
        hgroups.addContainerGap(1,2);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(editButton,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        hgroups.addContainerGap(10,30);
        hgroups.addGroup(groupLayout2.createParallelGroup().addComponent(button,GroupLayout.DEFAULT_SIZE,130,GroupLayout.PREFERRED_SIZE));
        groupLayout2.setVerticalGroup(vgroups);
        groupLayout2.setHorizontalGroup(hgroups);
        infos.setLayout(groupLayout2);



        //主要界面
        GroupLayout group=new GroupLayout(this);
        GroupLayout.SequentialGroup hgroup=group.createSequentialGroup();
        hgroup.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE)
                .addComponent(infos,GroupLayout.PREFERRED_SIZE,1200,GroupLayout.PREFERRED_SIZE));
        GroupLayout.SequentialGroup vgropu=group.createSequentialGroup();
        vgropu.addGroup(group.createParallelGroup().addComponent(seePanel,GroupLayout.PREFERRED_SIZE,600,GroupLayout.PREFERRED_SIZE));
        vgropu.addGroup(group.createParallelGroup().addComponent(infos,GroupLayout.PREFERRED_SIZE,200,GroupLayout.PREFERRED_SIZE));
        //添加到group里面
        group.setHorizontalGroup(hgroup);
        group.setVerticalGroup(vgropu);
        this.setLayout(group);





        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!(ID[0].equals(""))){
                    System.out.println(ID[0]);
                    drugs_exit.DeleteByID(ID[0]);
                    editButton.doClick();
                }
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int i=0;
                while (i<tableModel.getRowCount()){
                    tableModel.removeRow(i);
                }

                List<Map<String,Object>> lists= null;
                try {
                    lists = drugs_exit.SelectAllinfo();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                Map<String,Object> maps=null;
                for(int i1=0;i1< lists.size();i1++){
                    maps=lists.get(i1);
                    Object obj[]=new Object[]{maps.get("drugs_id"),maps.get("drugs_name"),maps.get("drugs_number")};
                    tableModel.addRow(obj);
                }
            }
        });
    }
}
