package XR.userComponet;

import javax.swing.*;
import javax.swing.table.TableCellEditor;

public class Jtable extends JTable {
    TableCellEditor Jcell;
    private int MyRow =-1,MyCol=-1;

    public Jtable(){
        super();
    }
    public void SetCom(int rows,int cols,TableCellEditor ce){
        MyRow=rows;
        MyCol=cols;
        Jcell=ce;
    }


    @Override
    public TableCellEditor getCellEditor(int row, int column) {
        if(row==MyRow&&column==MyCol&&Jcell!=null){
            return Jcell;
        }
        return super.getCellEditor(row,column);
    }
}


