package XR.userComponet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class LinkDocLable extends JLabel {
    public LinkDocLable(String text){

        //标签类容
        this.setText(text);
        //标签颜色
        this.setForeground(Color.cyan);
        this.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        this.addMouseListener(new MouseAdapter() {
            @Override
            //鼠标点击
            public void mouseClicked(MouseEvent e){
                File fl=new File("D:/javauml/recose/用户手册.doc");
                if(!fl.exists()) {
                    JOptionPane.showMessageDialog(null,
                            "文件不存在",
                            "",
                            INFORMATION_MESSAGE);
                    return;
                }
                if (Desktop.isDesktopSupported()) {
                    try {
                        Desktop.getDesktop().open(fl);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }

            }
            //鼠标进入
            public void mouseEntered(MouseEvent e) {
                setForeground(Color.MAGENTA);
            }

            //鼠标移动
            public void mouseExited(MouseEvent e) {
                setForeground(Color.cyan);
            }
        });
    }
}
