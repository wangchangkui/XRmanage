package XR.userComponet;

import javax.swing.*;

public class MyCom extends DefaultCellEditor {
    public MyCom(String[] item) {
        super(new JComboBox(item));
    }
}
