package XR.userComponet;


import XR.ui.Manager;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MenuLable extends JLabel {
    private static final long serialVersionUID = 1L;
    public MenuLable(String text, String name, Manager manager) {
        this.setText(text);
        this.setName(name);
        this.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        this.setBorder(new EtchedBorder(EtchedBorder.RAISED));
        this.setOpaque(true);
        Color color = this.getBackground();
        this.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(manager !=null){
                    manager.Switchtable(name);
                }
            }
            @Override
            public void mousePressed(MouseEvent e) {

            }
            @Override
            public void mouseReleased(MouseEvent e) {

            }
            @Override
            public void mouseEntered(MouseEvent e) {
                setBackground(new Color(3,169,244));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                setBackground(color);
            }
        });
    }
}
