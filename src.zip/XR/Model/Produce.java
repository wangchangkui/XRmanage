package XR.Model;

import XR.Model.Connect.Connect;


import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Produce {

    /*
    * 表 produce
    * */


    //1.查询数据
    public List<Map<String, Object>> SelectAllinfo() throws SQLException {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from produce";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        while (rs.next()){
            String Produce_id=rs.getString("Produce_id");
            String Produce_name=rs.getString("Produce_name");
            String Produce_peo=rs.getString("Produce_peo");
            String Produce_call=rs.getString("Produce_call");
            String Produce_addrucess=rs.getString("Produce_addrucess");
            String Produece_forget=rs.getString("Produece_forget");
            String Produce_Code=rs.getString("Produce_Code");
            String Produce_encode=rs.getString("Produce_encode");
            String Produce_Sell=rs.getString("Produce_Sell");
            map=new HashMap<String, Object>();
            map.put("Produce_id",Produce_id);
            map.put("Produce_name",Produce_name);
            map.put("Produce_peo",Produce_peo);
            map.put("Produce_call",Produce_call);
            map.put("Produce_addrucess",Produce_addrucess);
            map.put("Produece_forget",Produece_forget);
            map.put("Produce_Code",Produce_Code);
            map.put("Produce_encode",Produce_encode);
            map.put("Produce_Sell",Produce_Sell);
            list.add(map);
        }
        connect.ConnectClose(statement,connection,rs);
        return list;
    }

    //2.删除数据
    public void DeleteByID(String ID){
        String sql="Delete from produce where Produce_id='"+ID+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "数据以删除",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除数据失败，请检查信息",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println("DeleteById删除失败+"+e.toString());
        }
    }

    //3.修改数据
    public int UpdateInfo(Map<String,String> map){
        int ok=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="update produce set Produce_name='"+map.get("Produce_name")+"',Produce_peo='"+map.get("Produce_peo")+"',Produce_call='"+map.get("Produce_call")+"',Produce_addrucess='"+map.get("Produce_addrucess")+"',Produece_forget='"+map.get("Produece_forget")+"',Produce_Code='"+map.get("Produce_Code")+"',Produce_encode='"+map.get("Produce_encode")+"',Produce_Sell='"+map.get("Produce_Sell")+"' where Produce_id='"+map.get("Produce_id")+"'";
        try {
            statement= connection.createStatement();
            ok=statement.executeUpdate(sql);
        }catch (Exception e){
            System.out.println(e.toString());
        }
        return ok;
    }


    //4.增加数据

    public void insertProduce(Map<String,Object> map){
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement= connection.createStatement();
            String sql="INSERT INTO produce(Produce_id,Produce_name,Produce_peo,Produce_call,Produce_addrucess,Produece_forget,Produce_Code,Produce_encode,Produce_Sell) values('"+map.get("Produce_id")+"','"+map.get("Produce_name")+"','"+map.get("Produce_peo")+"','"+map.get("Produce_call")+"','"+map.get("Produce_addrucess")+"','"+map.get("Produece_forget")+"','"+map.get("Produce_Code")+"','"+map.get("Produce_encode")+"','"+map.get("Produce_Sell")+"')";
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "添加数据成功",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "联系管理员",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }


    /*
    * 3个查询条件获取数据 1.根据ID 2.根据简码 3.根据编码 4.所有条件
    * */

    public List<Map<String, Object>> SelectByID(String ID){
        String sql="select * from produce where Produce_id='"+ID+"'";

        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String Produce_id=rs.getString("Produce_id");
                String Produce_name=rs.getString("Produce_name");
                String Produce_peo=rs.getString("Produce_peo");
                String Produce_call=rs.getString("Produce_call");
                String Produce_addrucess=rs.getString("Produce_addrucess");
                String Produece_forget=rs.getString("Produece_forget");
                String Produce_Code=rs.getString("Produce_Code");
                String Produce_encode=rs.getString("Produce_encode");
                String Produce_Sell=rs.getString("Produce_Sell");
                map=new HashMap<String, Object>();
                map.put("Produce_id",Produce_id);
                map.put("Produce_name",Produce_name);
                map.put("Produce_peo",Produce_peo);
                map.put("Produce_call",Produce_call);
                map.put("Produce_addrucess",Produce_addrucess);
                map.put("Produece_forget",Produece_forget);
                map.put("Produce_Code",Produce_Code);
                map.put("Produce_encode",Produce_encode);
                map.put("Produce_Sell",Produce_Sell);


                list.add(map);
            }

            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }
        return list;
    }
    public List<Map<String, Object>> SelectByCode(String Code){
        String sql="select * from produce where Produce_Code='"+Code+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String Produce_id=rs.getString("Produce_id");
                String Produce_name=rs.getString("Produce_name");
                String Produce_peo=rs.getString("Produce_peo");
                String Produce_call=rs.getString("Produce_call");
                String Produce_addrucess=rs.getString("Produce_addrucess");
                String Produece_forget=rs.getString("Produece_forget");
                String Produce_Code=rs.getString("Produce_Code");
                String Produce_encode=rs.getString("Produce_encode");
                String Produce_Sell=rs.getString("Produce_Sell");
                map=new HashMap<String, Object>();
                map.put("Produce_id",Produce_id);
                map.put("Produce_name",Produce_name);
                map.put("Produce_peo",Produce_peo);
                map.put("Produce_call",Produce_call);
                map.put("Produce_addrucess",Produce_addrucess);
                map.put("Produece_forget",Produece_forget);
                map.put("Produce_Code",Produce_Code);
                map.put("Produce_encode",Produce_encode);
                map.put("Produce_Sell",Produce_Sell);
                list.add(map);
            }



            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }
    public List<Map<String, Object>> SelectByencode(String encode){
        String sql="select * from produce where Produce_encode='"+encode+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String Produce_id=rs.getString("Produce_id");
                String Produce_name=rs.getString("Produce_name");
                String Produce_peo=rs.getString("Produce_peo");
                String Produce_call=rs.getString("Produce_call");
                String Produce_addrucess=rs.getString("Produce_addrucess");
                String Produece_forget=rs.getString("Produece_forget");
                String Produce_Code=rs.getString("Produce_Code");
                String Produce_encode=rs.getString("Produce_encode");
                String Produce_Sell=rs.getString("Produce_Sell");
                map=new HashMap<String, Object>();
                map.put("Produce_id",Produce_id);
                map.put("Produce_name",Produce_name);
                map.put("Produce_peo",Produce_peo);
                map.put("Produce_call",Produce_call);
                map.put("Produce_addrucess",Produce_addrucess);
                map.put("Produece_forget",Produece_forget);
                map.put("Produce_Code",Produce_Code);
                map.put("Produce_encode",Produce_encode);
                map.put("Produce_Sell",Produce_Sell);
                list.add(map);
            }



            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }
    public List<Map<String, Object>> SelectAllif(String ID, String Code, String encode){
        String sql="select * from produce where Produce_id='"+ID+"' and Produce_Code='"+Code+"' and Produce_encode='"+encode+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域

            while (rs.next()){
                String Produce_id=rs.getString("Produce_id");
                String Produce_name=rs.getString("Produce_name");
                String Produce_peo=rs.getString("Produce_peo");
                String Produce_call=rs.getString("Produce_call");
                String Produce_addrucess=rs.getString("Produce_addrucess");
                String Produece_forget=rs.getString("Produece_forget");
                String Produce_Code=rs.getString("Produce_Code");
                String Produce_encode=rs.getString("Produce_encode");
                String Produce_Sell=rs.getString("Produce_Sell");
                map=new HashMap<String, Object>();
                map.put("Produce_id",Produce_id);
                map.put("Produce_name",Produce_name);
                map.put("Produce_peo",Produce_peo);
                map.put("Produce_call",Produce_call);
                map.put("Produce_addrucess",Produce_addrucess);
                map.put("Produece_forget",Produece_forget);
                map.put("Produce_Code",Produce_Code);
                map.put("Produce_encode",Produce_encode);
                map.put("Produce_Sell",Produce_Sell);
                list.add(map);
            }


            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }

    //获取数量
    public int count() throws SQLException {
        int count=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select count(*) from Produce";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        while (rs.next()){
            count=Integer.parseInt(rs.getString("count(*)"));
        }
        connect.ConnectClose(statement, connection, rs);
        return count;
    }


    public Object[] ProName() throws SQLException {
        Object[] obj=new Object[count()];
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select Produce_name from produce";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        int i=0;
        while (rs.next()){
            String Produce_name=rs.getString("Produce_name");
            obj[i]=Produce_name;
            i++;
        }
        connect.ConnectClose(statement,connection,rs);
        return obj;
    }
}
