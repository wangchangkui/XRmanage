package XR.Model;

import XR.Model.Connect.Connect;

import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Drugs_class {
    //所有数据
    public List<Map<String, Object>> SelectAllinfo() throws SQLException {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from drugs_class";
        //drugs_name	drugs_peo	drugs_pro_call	drugs_area	drugs_address	drugs_room_code	address_code	drugs_room_area_address
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        while (rs.next()){
            String drugs_id=rs.getString("drugs_id");
            String drugs_code=rs.getString("drugs_code");
            String drugs_name=rs.getString("drugs_name");

            map=new HashMap<String, Object>();
            map.put("drugs_id",drugs_id);
            map.put("drugs_code",drugs_code);
            map.put("drugs_name",drugs_name);

            list.add(map);
        }
        connect.ConnectClose(statement,connection,rs);
        return list;
    }


    public void insertDrugs_room(Map<String,Object> map){
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement= connection.createStatement();
            String sql="INSERT INTO drugs_class(drugs_id,drugs_code,drugs_name) values('"+map.get("drugs_id")+"','"+map.get("drugs_code")+"','"+map.get("drugs_name")+"')";
            System.out.println(sql);
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "添加数据成功",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "联系管理员",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }


    public List<Map<String, Object>> SelectByID(String ID){
        String sql="select * from drugs_class where drugs_id='"+ID+"'";
        System.out.println(sql);
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);
            //此处为数据待处理区域
            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_code=rs.getString("drugs_code");
                String drugs_name=rs.getString("drugs_name");

                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_code",drugs_code);
                map.put("drugs_name",drugs_name);

                list.add(map);
            }

            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }
        return list;
    }


    public List<Map<String, Object>> SelectByCode(String Code){
        String sql="select * from drugs_class where drugs_code='"+Code+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_code=rs.getString("drugs_code");
                String drugs_name=rs.getString("drugs_name");

                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_code",drugs_code);
                map.put("drugs_name",drugs_name);

                list.add(map);
            }



            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }

    public List<Map<String, Object>> SelectAllif(String ID, String Code){
        String sql="select * from drugs_class where drugs_id='"+ID+"' and drugs_code='"+Code+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域

            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_code=rs.getString("drugs_code");
                String drugs_name=rs.getString("drugs_name");

                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_code",drugs_code);
                map.put("drugs_name",drugs_name);

                list.add(map);
            }


            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }


    public void DeleteByID(String ID){
        String sql="Delete from drugs_class where drugs_id='"+ID+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "数据以删除",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除数据失败，请检查信息",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println("DeleteById删除失败+"+e.toString());
        }
    }

    public int UpdateInfo(Map<String,String> map){
        int ok=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="update drugs_class set drugs_code='"+map.get("drugs_code")+"',drugs_name='"+map.get("drugs_name")+"' where drugs_id='"+map.get("drugs_id")+"'";
        try {
            statement= connection.createStatement();
            ok=statement.executeUpdate(sql);
            if(ok==1){
                System.out.println("更新成功");
            }
            connect.ConnectClose(statement, connection);
        }catch (Exception e){
            System.out.println(e.toString());
        }
        return ok;
    }


    public int count(){
        int count=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select count(*) from drugs_class";
        try {
            statement= connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            while (rs.next()){
                count=Integer.parseInt(rs.getString("count(*)"));
            }
            connect.ConnectClose(statement,connection,rs);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return count;
    }
}
