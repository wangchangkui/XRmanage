package XR.Model.Connect;

import javax.xml.transform.Result;
import java.net.URL;
import java.sql.*;


public class Connect {
    final static String JDBC="com.mysql.jdbc.Driver";
    private  final static String URl="jdbc:mysql://localhost:3306/XRManeger?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    final static String username="root";
    final static String password="root";

    /*
    * 测试Sql
    * Class.forName(JDBC) 加载驱动器
    * DriverManager.getConnection(URl,password,username) 连接数据库
    *  ResultSet rs=statement.executeQuery(sql) 执行sql语句
    * */
    public void SQlTest() {
        Connection conn=null;
        Statement statement=null;
        try {
            Class.forName(JDBC);
            conn=DriverManager.getConnection(URl,username,password);
            statement=conn.createStatement();
            String sql="select * from users";
            ResultSet rs=statement.executeQuery(sql);
            while (rs.next()){
                System.out.println("UserID"+rs.getString("UserID"));
                System.out.println("Username"+rs.getString("Username"));
                System.out.println("password"+rs.getString("password"));
                System.out.println("flag"+rs.getString("flag"));
            }
            rs.close();
            conn.close();
            statement.close();
            System.out.println("ok");
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }

    //单独的连接
    public Connection ConnectSql(){
        Connection conn=null;
        try {
            Class.forName(JDBC);
            conn=DriverManager.getConnection(URl,username,password);
            return conn;
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return conn;
    }

    //单独的断开
    public void ConnectClose(Statement statement, Connection conn, ResultSet rs) throws SQLException {
        statement.close();
        conn.close();
        rs.close();
    }

    public void ConnectClose(Statement statement, Connection conn) throws SQLException {
        statement.close();
        conn.close();
    }

}
