package XR.Model;

import XR.Model.Connect.Connect;

import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;



public class Manager {
    //获取Manager所有数据
    public ResultSet getAllManager() throws SQLException {
        ResultSet rs=null;
        Connect conn=new Connect();
        Connection connection=conn.ConnectSql();
        Statement statement=null;
        String sql="select * from maneger";
        try {
            statement=connection.createStatement();
            rs=statement.executeQuery(sql);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return rs;
    }


    //查询管理员是否存在
    public Boolean SelectManeger(String name) throws SQLException {
        Boolean ok=true;
        Connect conn=new Connect();
        Connection connection=conn.ConnectSql();
        Statement statement=null;
        ResultSet rs;
        try {
            statement=connection.createStatement();
            String sql="select maneger from maneger where maneger='"+name+"'";
            rs=statement.executeQuery(sql);
            if(rs.next()){
                ok=false;
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
            JOptionPane.showMessageDialog(null,
                    "添加失败 请检查代码",
                    "数据库",
                    INFORMATION_MESSAGE);
        }

        conn.ConnectClose(statement,connection);
        return ok;
    }

    //添加数据
    public Integer insertManeger(String name,Integer flag) throws SQLException {
        int rs=3;
        Connect conn=new Connect();
        Connection connection=conn.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            String sql="INSERT INTO maneger(flag,maneger) values('"+flag+"','"+name+"')";
            Boolean info=this.SelectManeger(name);
            if(info){
                rs=statement.executeUpdate(sql);
                if(rs==1){
                    JOptionPane.showMessageDialog(null,
                            "添加数据成功",
                            "数据库",
                            INFORMATION_MESSAGE);
                }
                else{
                    JOptionPane.showMessageDialog(null,
                            "添加失败 请检查代码",
                            "数据库",
                            INFORMATION_MESSAGE);
                }
                conn.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "添加失败 数据已存在",
                        "数据库",
                        INFORMATION_MESSAGE);
            }

        }
        catch (Exception e){
            System.out.println(e.toString());
            JOptionPane.showMessageDialog(null,
                    "添加失败 请检查代码",
                    "数据库",
                    INFORMATION_MESSAGE);
        }
        conn.ConnectClose(statement,connection);
        return rs;
    }


    //删除数据

    public void DeleteManger(String maneger) throws SQLException {
        Connect conn=new Connect();
        Connection connection=conn.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            String sql="Delete from maneger where maneger='"+maneger+"'";
            int ok=statement.executeUpdate(sql);

            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "删除成功",
                        "数据库",
                        INFORMATION_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除失败 数据不存在",
                        "数据库",
                        INFORMATION_MESSAGE);
            }
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
        conn.ConnectClose(statement,connection);
    }


    //修改数据源
    public void UpdataInfo(String ID,String Name) throws SQLException {
        Connect conn=new Connect();
        Connection connection=conn.ConnectSql();
        Statement statement=null;
        try {
            int ok;
            statement = connection.createStatement();
            String sql="Update maneger Set maneger='"+Name+"' where ID='"+ID+"'";
            ok=statement.executeUpdate(sql);
            if(ok==1){
                System.out.println("ok");
            }
            else{
                System.out.println(ID+"|"+Name);
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        conn.ConnectClose(statement,connection);
    }


    //获取数据库行数
    public Integer count() throws SQLException {
        Integer count=0;
        Connect connect=new Connect();
        Statement statement=null;
        Connection connection=connect.ConnectSql();
        String sql="select count(*) from maneger";
        try {
            statement=connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            while (rs.next()){
                count=Integer.parseInt(rs.getString("count(*)"));
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return count;
    }


    //根据名称 查找ID
    public String ID(String name) throws SQLException {
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String IDs="";
        ResultSet rs=null;
        try {
            statement=connection.createStatement();
            String sql="select ID from maneger where maneger='"+name+"'";
            rs=statement.executeQuery(sql);

            while (rs.next()){
                IDs=rs.getString("ID");
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
            return "";
        }
        connect.ConnectClose(statement,connection,rs);
        return IDs;
    }


    //根据名称 查找flag
    public String flag(String name) throws SQLException {
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String IDs="";
        ResultSet rs=null;
        try {
            statement=connection.createStatement();
            String sql="select flag from maneger where maneger='"+name+"'";
            rs=statement.executeQuery(sql);

            while (rs.next()){
                IDs=rs.getString("flag");
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
            return "";
        }
        connect.ConnectClose(statement,connection,rs);
        return IDs;
    }
}
