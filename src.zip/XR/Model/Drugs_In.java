package XR.Model;

import XR.Model.Connect.Connect;

import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Drugs_In {
    //1.显示所有数据

    public List<Map<String, Object>> selectAll() throws SQLException {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from drugs_in";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);


        while (rs.next()){
            String 	drugs_id=rs.getString("drugs_id");
            String drugs_name=rs.getString("drugs_name");
            String drugs_pro=rs.getString("drugs_pro");
            String drugs_peo=rs.getString("drugs_peo");
            String drugs_nums=rs.getString("drugs_nums");
            String drugs_day=rs.getString("drugs_day");
            String 	drugs_time=rs.getString("drugs_time");
            String drugs_pro_time=rs.getString("drugs_pro_time");
            String drugs_price=rs.getString("drugs_price");
            map=new HashMap<String, Object>();
            map.put("drugs_id",drugs_id);
            map.put("drugs_name",drugs_name);
            map.put("drugs_pro",drugs_pro);
            map.put("drugs_peo",drugs_peo);
            map.put("drugs_nums",drugs_nums);
            map.put("drugs_day",drugs_day);
            map.put("drugs_time",drugs_time);
            map.put("drugs_pro_time",drugs_pro_time);
            map.put("drugs_price",drugs_price);
            list.add(map);
        }
        connect.ConnectClose(statement, connection, rs);
        return list;
    }


    //获取数据库总行数
    public int countAll() throws SQLException {
        int count=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select count(*) from drugs_in";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);

        while (rs.next()){
            count=Integer.parseInt(rs.getString("count(*)"));
        }
        connect.ConnectClose(statement, connection, rs);
        return count;
    }


    //更新数据
    public int  update(Map<String,String> map) throws SQLException {
        int ok=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;


        String sql="update drugs_in set drugs_name='"+map.get("drugs_name")+"',drugs_pro='"+map.get("drugs_pro")+"',drugs_peo='"+map.get("drugs_peo")+"',drugs_nums='"+map.get("drugs_nums")+"',drugs_day='"+map.get("drugs_day")+"',drugs_time='"+map.get("drugs_time")+"',drugs_pro_time='"+map.get("drugs_pro_time")+"',drugs_price='"+map.get("drugs_price")+"' where drugs_id='"+map.get("drugs_id")+"'";
        try {
            statement= connection.createStatement();
            ok=statement.executeUpdate(sql);
            if(ok==1){
                System.out.println("更新成功");
            }
            connect.ConnectClose(statement, connection);
        }catch (Exception e){
            System.out.println(e.toString());
        }
        connect.ConnectClose(statement, connection);
        return ok;
    }

    //添加数据
    public void insert(Map<String,Object> map) throws SQLException {

        String sql="INSERT INTO drugs_in(drugs_id,drugs_name,drugs_pro,drugs_peo,drugs_nums,drugs_day,drugs_time,drugs_pro_time,drugs_price) values('"+map.get("drugs_id")+"','"+map.get("drugs_name")+"','"+map.get("drugs_pro")+"','"+map.get("drugs_peo")+"','"+map.get("drugs_nums")+"','"+map.get("drugs_day")+"','"+map.get("drugs_time")+"','"+map.get("drugs_pro_time")+"','"+map.get("drugs_price")+"')";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement= connection.createStatement();
            System.out.println(sql);
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "添加数据成功",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "联系管理员",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch ( Exception e){
            System.out.println(e.toString());
        }
        connect.ConnectClose(statement, connection);
    }

    //删除数据
    public void DeletDrug(String ID) throws SQLException {
        String sql="Delete from drugs_in where drugs_id='"+ID+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "数据以删除",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除数据失败，请检查信息",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println("DeleteById删除失败+"+e.toString());
        }
        connect.ConnectClose(statement, connection);
    }

}
