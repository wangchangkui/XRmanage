package XR.Model;

import XR.Model.Connect.Connect;

import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Drugs {


    //所有数据
    public List<Map<String, Object>> SelectAllinfo() throws SQLException {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from drugs";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        while (rs.next()){
            String drugs_id=rs.getString("drugs_id");
            String drugs_name=rs.getString("drugs_name");
            String drugs_peo=rs.getString("drugs_peo");
            String drugs_address=rs.getString("drugs_address");
            String drugs_class=rs.getString("drugs_class");
            String drugs_price=rs.getString("drugs_price");
            String drugs_code=rs.getString("drugs_code");
            String drugs_number=rs.getString("drugs_number");
            String drugs_time=rs.getString("drugs_time");
            map=new HashMap<String, Object>();
            map.put("drugs_id",drugs_id);
            map.put("drugs_name",drugs_name);
            map.put("drugs_peo",drugs_peo);
            map.put("drugs_address",drugs_address);
            map.put("drugs_class",drugs_class);
            map.put("drugs_price",drugs_price);
            map.put("drugs_code",drugs_code);
            map.put("drugs_number",drugs_number);
            map.put("drugs_time",drugs_time);
            list.add(map);
        }
        connect.ConnectClose(statement,connection,rs);
        return list;
    }


    public void insertComplay(Map<String,Object> map){
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement= connection.createStatement();
            String sql="INSERT INTO drugs(drugs_id,drugs_name,drugs_peo,drugs_address,drugs_class,drugs_price,drugs_code,drugs_number,drugs_time) values('"+map.get("drugs_id")+"','"+map.get("drugs_name")+"','"+map.get("drugs_peo")+"','"+map.get("drugs_address")+"','"+map.get("drugs_class")+"','"+map.get("drugs_price")+"','"+map.get("drugs_code")+"','"+map.get("drugs_number")+"','"+map.get("drugs_time")+"')";

            System.out.println(sql);
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "添加数据成功",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "联系管理员",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }


    public List<Map<String, Object>> SelectByID(String ID){
        String sql="select * from drugs where drugs_id='"+ID+"'";
        System.out.println(sql);
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);
            //此处为数据待处理区域
            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_name=rs.getString("drugs_name");
                String drugs_peo=rs.getString("drugs_peo");
                String drugs_address=rs.getString("drugs_address");
                String drugs_class=rs.getString("drugs_class");
                String drugs_price=rs.getString("drugs_price");
                String drugs_code=rs.getString("drugs_code");
                String drugs_number=rs.getString("drugs_number");
                String drugs_time=rs.getString("drugs_time");
                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_name",drugs_name);
                map.put("drugs_peo",drugs_peo);
                map.put("drugs_address",drugs_address);
                map.put("drugs_class",drugs_class);
                map.put("drugs_price",drugs_price);
                map.put("drugs_code",drugs_code);
                map.put("drugs_number",drugs_number);
                map.put("drugs_time",drugs_time);
                list.add(map);
            }

            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }
        return list;
    }
    public List<Map<String, Object>> SelectByCode(String Code){
        String sql="select * from drugs where drugs_name='"+Code+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_name=rs.getString("drugs_name");
                String drugs_peo=rs.getString("drugs_peo");
                String drugs_address=rs.getString("drugs_address");
                String drugs_class=rs.getString("drugs_class");
                String drugs_price=rs.getString("drugs_price");
                String drugs_code=rs.getString("drugs_code");
                String drugs_number=rs.getString("drugs_number");
                String drugs_time=rs.getString("drugs_time");
                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_name",drugs_name);
                map.put("drugs_peo",drugs_peo);
                map.put("drugs_address",drugs_address);
                map.put("drugs_class",drugs_class);
                map.put("drugs_price",drugs_price);
                map.put("drugs_code",drugs_code);
                map.put("drugs_number",drugs_number);
                map.put("drugs_time",drugs_time);
                list.add(map);
            }



            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }

    public List<Map<String, Object>> select_class(String encode){
        String sql="select * from drugs where drugs_class='"+encode+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_name=rs.getString("drugs_name");
                String drugs_peo=rs.getString("drugs_peo");
                String drugs_address=rs.getString("drugs_address");
                String drugs_class=rs.getString("drugs_class");
                String drugs_price=rs.getString("drugs_price");
                String drugs_code=rs.getString("drugs_code");
                String drugs_number=rs.getString("drugs_number");
                String drugs_time=rs.getString("drugs_time");
                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_name",drugs_name);
                map.put("drugs_peo",drugs_peo);
                map.put("drugs_address",drugs_address);
                map.put("drugs_class",drugs_class);
                map.put("drugs_price",drugs_price);
                map.put("drugs_code",drugs_code);
                map.put("drugs_number",drugs_number);
                map.put("drugs_time",drugs_time);
                list.add(map);
            }



            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }
    public List<Map<String, Object>> SelectAllif(String ID, String Code, String drugs_classs){
        String sql="select * from drugs where drugs_id='"+ID+"' and drugs_code='"+Code+"' and drugs_class='"+drugs_classs+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域

            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_name=rs.getString("drugs_name");
                String drugs_peo=rs.getString("drugs_peo");
                String drugs_address=rs.getString("drugs_address");
                String drugs_class=rs.getString("drugs_class");
                String drugs_price=rs.getString("drugs_price");
                String drugs_code=rs.getString("drugs_code");
                String drugs_number=rs.getString("drugs_number");
                String drugs_time=rs.getString("drugs_time");
                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_name",drugs_name);
                map.put("drugs_peo",drugs_peo);
                map.put("drugs_address",drugs_address);
                map.put("drugs_class",drugs_class);
                map.put("drugs_price",drugs_price);
                map.put("drugs_code",drugs_code);
                map.put("drugs_number",drugs_number);
                map.put("drugs_time",drugs_time);
                list.add(map);
            }


            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }


    public void DeleteByID(String ID){
        String sql="Delete from drugs where drugs_id='"+ID+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "数据以删除",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除数据失败，请检查信息",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println("DeleteById删除失败+"+e.toString());
        }
    }



    public int UpdateInfo(Map<String,String> map){
        int ok=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="update drugs set drugs_name='"+map.get("drugs_name")+"',drugs_peo='"+map.get("drugs_peo")+"',drugs_address='"+map.get("drugs_address")+"',drugs_class='"+map.get("drugs_class")+"',drugs_price='"+map.get("drugs_price")+"',drugs_code='"+map.get("drugs_code")+"',drugs_number='"+map.get("drugs_number")+"',drugs_time='"+map.get("drugs_time")+"' where drugs_id='"+map.get("drugs_id")+"'";
        try {
            statement= connection.createStatement();
            ok=statement.executeUpdate(sql);


            if(ok==1){
                System.out.println("更新成功");
            }
            connect.ConnectClose(statement, connection);
        }catch (Exception e){
            System.out.println(e.toString());
        }
        return ok;
    }


    public int count(){
        int count=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select count(*) from drugs";
        try {
            statement= connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            while (rs.next()){
                count=Integer.parseInt(rs.getString("count(*)"));
            }
            connect.ConnectClose(statement,connection,rs);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return count;
    }

    //获取所有的药品名称
    public Object[] getDrug_name(){
        Object[] objects=new Object[count()];
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select drugs_name from drugs";
        try {
            statement= connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            int i=0;
            while (rs.next()){
                objects[i]=rs.getString("drugs_name");
                i++;
            }
            connect.ConnectClose(statement,connection,rs);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return objects;
    }

    //获取所有的药品出产商
    public Object[] getDrug_address(){
        Object[] objects=new Object[count()];
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select drugs_address from drugs";
        try {
            statement= connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            int i=0;
            while (rs.next()){
                objects[i]=rs.getString("drugs_address");
                i++;
            }
            connect.ConnectClose(statement,connection,rs);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return objects;
    }

    //获取所有的药品负责人
    public Object[] getDrug_peo(){
        Object[] objects=new Object[count()];
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select drugs_peo from drugs";
        try {
            statement= connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            int i=0;
            while (rs.next()){
                objects[i]=rs.getString("drugs_peo");
                i++;
            }
            connect.ConnectClose(statement,connection,rs);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return objects;
    }

    //获取药品名称
    public Object[] getDrugs_name(){
        Object[] objects=new Object[count()];
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select drugs_name from drugs";
        try {
            statement= connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            int i=0;
            while (rs.next()){
                objects[i]=rs.getString("drugs_name");
                i++;
            }
            connect.ConnectClose(statement,connection,rs);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return objects;
    }


    //根据ID 查询数据
    public Map<String, Object> selectInfo(String id){
        Map<String, Object> map=new HashMap<>();
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from drugs where drugs_id='"+id+"'";
        try {
            statement= connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);

            while (rs.next()){
                map.put("drugs_id",rs.getString("drugs_id"));
                map.put("drugs_name",rs.getString("drugs_name"));
                map.put("drugs_price",rs.getString("drugs_price"));
                map.put("drugs_number",rs.getString("drugs_number"));
            }
            connect.ConnectClose(statement,connection,rs);
        }
        catch ( Exception e){
            System.out.println(e.getMessage());
        }
        return map;
    }


    //更新售价
    public void updatePrice(Object[] obj){
        String sql="update drugs set drugs_price='"+obj[1]+"' where drugs_id='"+obj[0]+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            statement.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,
                    "以更新价格",
                    "数据库信息",
                    INFORMATION_MESSAGE);
            connect.ConnectClose(statement, connection);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }

    }


    //查询数量
    //所有数据
    public List<Map<String, Object>> SelectAllinfoWhereNumer() throws SQLException {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from drugs where drugs_number<100";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        while (rs.next()){
            String drugs_id=rs.getString("drugs_id");
            String drugs_name=rs.getString("drugs_name");
            String drugs_number=rs.getString("drugs_number");
            map=new HashMap<String, Object>();
            map.put("drugs_id",drugs_id);
            map.put("drugs_name",drugs_name);
            map.put("drugs_number",drugs_number);
            list.add(map);
        }
        connect.ConnectClose(statement,connection,rs);
        return list;
    }

    public int update(Map<String,String> map) throws SQLException {
        int ok=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="update drugs set drugs_number='"+map.get("drugs_nums")+"' where drugs_id='"+map.get("drugs_id")+"'";
        try {
            statement= connection.createStatement();
            ok=statement.executeUpdate(sql);
            if(ok==1){
                System.out.println("更新成功");
            }
            connect.ConnectClose(statement, connection);
        }catch (Exception e){
            System.out.println(e.toString());
        }
        connect.ConnectClose(statement, connection);
        return ok;
    }
}
