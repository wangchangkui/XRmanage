package XR.Model;

import XR.Model.Connect.Connect;

import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Drugs_Book {
    //添加数据
    public void insert(Map<String,Object> map) throws SQLException {
        String sql="INSERT INTO drugs_book(book_id,content) values('"+map.get("book_id")+"','"+map.get("content")+"')";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement= connection.createStatement();
            System.out.println(sql);
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "已添加到待审批报表中",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "联系管理员",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch ( Exception e){
            System.out.println(e.toString());
        }
        connect.ConnectClose(statement, connection);
    }

    //获取所有数据
    public List<Map<String, Object>> selectAll() throws SQLException {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from drugs_book";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);


        while (rs.next()){
            String 	book_id=rs.getString("book_id");
            String content=rs.getString("content");
            String flag=rs.getString("flag");

            if(flag.equals("1")){
                flag="审核通过";
            }else{
                flag="审核未通过";
            }


            map=new HashMap<String, Object>();
            map.put("book_id",book_id);
            map.put("content",content);
            map.put("flag",flag);
            list.add(map);
        }
        connect.ConnectClose(statement, connection, rs);
        return list;
    }


    //更新数据
    public void update(String id,String on){


        String sql1="select flag from drugs_book where book_id='"+id+"'";
        String sql2="update drugs_book set flag=1 where book_id='"+id+"'";
        String sql3="update drugs_book set flag=0 where book_id='"+id+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            ResultSet resultSet= statement.executeQuery(sql1);
            String flag=null;
            while (resultSet.next()){
                flag=resultSet.getString("flag");
            }


            if(!flag.equals("1")&&on.equals("1")){
                statement.executeUpdate(sql2);
                JOptionPane.showMessageDialog(null,
                        "审核以通过",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
            else if(flag.equals("1")&&on.equals("1")){
                JOptionPane.showMessageDialog(null,
                        "审核以通过",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
            else if(flag.equals("1")&&on.equals("0")){
                statement.executeUpdate(sql3);
                JOptionPane.showMessageDialog(null,
                        "已拒绝次单据",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
            else if(flag.equals("0")&&on.equals("0")){
                JOptionPane.showMessageDialog(null,
                        "已拒绝次单据",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }

            connect.ConnectClose(statement, connection, resultSet);
        }
        catch ( Exception e){
            System.out.println(e.getMessage());
        }


    }

    //删除数据
    public void DeletDrug(String ID) throws SQLException {
        String sql="Delete from drugs_book where book_id='"+ID+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "数据以删除",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除数据失败，请检查信息",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println("DeleteById删除失败+"+e.toString());
        }
        connect.ConnectClose(statement, connection);
    }
}
