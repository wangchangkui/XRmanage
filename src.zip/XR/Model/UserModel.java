package XR.Model;

import XR.Model.Connect.Connect;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class UserModel {




    //查询Users 表里面所有数据
    public ResultSet infos(){
        ResultSet rs=null;
        Connect conn=new Connect();
        Connection st=conn.ConnectSql();
        String sql="select * from users";
        try {
            Statement statement=null;
            statement=st.createStatement();
            rs=statement.executeQuery(sql);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"无法连接到数据库::+'"+e.toString()+"'","数据库错误", JOptionPane.ERROR_MESSAGE);
            System.out.println(e.toString());
        }
        return rs;
    }

    /*
    * 同上
    * */

    public ResultSet Listinfos() throws SQLException {
        ResultSet rs=null;
        Connect conn=new Connect();
        Connection st=conn.ConnectSql();
        String sql="select * from users";
        Statement statement=null;
         try {
            statement=st.createStatement();
            rs=statement.executeQuery(sql);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error::+'"+e.toString()+"'","数据库错误", JOptionPane.ERROR_MESSAGE);
            System.out.println(e.toString());
        }
        return rs;
    }

    /*
    * 登录测试
    * */
    public Map Login(String username, String password){
        Connect conn=new Connect();
        Connection st=conn.ConnectSql();
        Statement statement=null;
        ResultSet resultSet=null;
        String sql="select * from users where Username='"+username+"' and password='"+password+"'";
        Map<String,String>map=new HashMap<String,String>();
        try {
            statement=st.createStatement();
            resultSet=statement.executeQuery(sql);
            while (resultSet.next()){
                 map.put("flag",resultSet.getString("flag"));
                 map.put("Username",resultSet.getString("Username"));
                 map.put("password",resultSet.getString("password"));
            }
            resultSet.close();
            st.close();
            statement.close();
            return map;
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return map;
    }


    //根据名字找到对应的ID并修改
    public boolean EditPassword(String pass1,String pass2,String pass3,String username) throws SQLException {
        Connect conn=new Connect();
        Connection st=conn.ConnectSql();
        Statement statement=null;
        ResultSet resultSet=null;
        if(pass1.toString().equals(pass2)){
            String sql="update users set password='"+pass3+"' where Username='"+username+"';";
            try {
                statement=st.createStatement();
                int rs=statement.executeUpdate(sql);
                if(rs==1){

                    return true;
                }
                else{

                    return false;
                }
            }
            catch (Exception e){
                System.out.println(e.toString());
            }


        }
        return false;
    }




    //查询名称是否被使用了
    public Integer NameExit(String name){
        Integer Exit=1;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        String sql="select Username from users where Username='"+name+"'";
        try {
            statement=connection.createStatement();
            rs=statement.executeQuery(sql);
            if(rs.next()){
                Exit=0;
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return Exit;
    }



    //添加数据
    public void insert(String username,String password,String flag,String flagName){
        int random= (int) ((Math.random()*10000)+Math.random()*101010);
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="INSERT INTO users(UserID,Username,password,flag,flagname) values('"+random+"','"+username+"','"+password+"','"+flag+"','"+flagName+"')";
        try {
            statement=connection.createStatement();
            int i=statement.executeUpdate(sql);
            if(i==1){
                JOptionPane.showMessageDialog(null,
                        "添加数据成功",
                        "数据库的消息",
                        INFORMATION_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "未知的错误 检查UserModel中的insert方法",
                        "INFO",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }


    //根据ID 查找数据
    public ArrayList SelectID(String ID) throws SQLException {
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        String sql="select * from users where UserID='"+ID+"'";
        ArrayList arrayList=new ArrayList();
        try {
            statement=connection.createStatement();
            rs=statement.executeQuery(sql);
            while (rs.next()){

                arrayList.add(0,rs.getString("UserID"));
                arrayList.add(1,rs.getString("Username"));
                arrayList.add(2,rs.getString("password"));
                arrayList.add(3,rs.getString("flagname"));
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        connect.ConnectClose(statement,connection,rs);
        return arrayList;
    }

    //获取数据库总行数
    public int countRow() throws SQLException {
        int count=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        String sql="select count(*) from users";
        try {
            statement=connection.createStatement();
            rs=statement.executeQuery(sql);
            while (rs.next()){
                count= Integer.parseInt(rs.getString("count(*)"));
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        connect.ConnectClose(statement,connection,rs);
        return count;
    }

    //根据ID 删除数据

    public void DeleteWithID(String ID){
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="Delete from users where UserID='"+ID+"'";
        try {
            statement=connection.createStatement();
            int i=statement.executeUpdate(sql);
            if(i==1){
                JOptionPane.showMessageDialog(null,
                        "删除成功",
                        "来自数据库的信息",
                        INFORMATION_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除失败，ID不存在",
                        "来自数据库的信息",
                        INFORMATION_MESSAGE);
            }

        }catch (Exception e){
            System.out.println(e.toString());
        }
    }


    //根据名字找到ID
    public String SeletcID(String Username) throws SQLException {
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        String sql="select UserID from users where Username='"+Username+"'";
        String ID=null;
        try {
            statement=connection.createStatement();
            rs=statement.executeQuery(sql);
            while (rs.next()){
                ID=rs.getString("UserID");
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        connect.ConnectClose(statement,connection,rs);
        return ID;
    }


    //修改数据
    public void update(String ID,String name,String flag){
        String sql="UPDATE `users` SET`Username`='"+name+"',`flagname`='"+flag+"' WHERE UserID="+ID+"";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement= connection.createStatement();
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "修改成功,下次重新进入即可查看",
                        "来自数据库的信息",
                        INFORMATION_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "修改失败 检查传入的值",
                        "来自数据库的信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }
}
