package XR.Model;

import XR.Model.Connect.Connect;

import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Complay {


    //所有数据
    public List<Map<String, Object>> SelectAllinfo() throws SQLException {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from complay";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        while (rs.next()){
            String complay_id=rs.getString("complay_id");
            String complay_name=rs.getString("complay_name");
            String complay_peo=rs.getString("complay_peo");
            String complay_peo_call=rs.getString("complay_peo_call");
            String complay_address=rs.getString("complay_address");
            String complay_forget=rs.getString("complay_forget");
            String complay_code=rs.getString("complay_code");
            String complay_encode=rs.getString("complay_encode");
            String complay_sell=rs.getString("complay_sell");
            map=new HashMap<String, Object>();
            map.put("complay_id",complay_id);
            map.put("complay_name",complay_name);
            map.put("complay_peo",complay_peo);
            map.put("complay_peo_call",complay_peo_call);
            map.put("complay_address",complay_address);
            map.put("complay_forget",complay_forget);
            map.put("complay_code",complay_code);
            map.put("complay_encode",complay_encode);
            map.put("complay_sell",complay_sell);
            list.add(map);
        }
        connect.ConnectClose(statement,connection,rs);
        return list;
    }


    public void insertComplay(Map<String,Object> map){
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement= connection.createStatement();
            String sql="INSERT INTO complay(complay_id,complay_name,complay_peo,complay_peo_call,complay_address,complay_forget,complay_code,complay_encode,complay_sell) values('"+map.get("complay_id")+"','"+map.get("complay_name")+"','"+map.get("complay_peo")+"','"+map.get("complay_peo_call")+"','"+map.get("complay_address")+"','"+map.get("complay_forget")+"','"+map.get("complay_code")+"','"+map.get("complay_encode")+"','"+map.get("complay_sell")+"')";
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "添加数据成功",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "联系管理员",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }


    public List<Map<String, Object>> SelectByID(String ID){
        String sql="select * from complay where complay_id='"+ID+"'";
        System.out.println(sql);
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);
            //此处为数据待处理区域
            while (rs.next()){
                String complay_id=rs.getString("complay_id");
                String complay_name=rs.getString("complay_name");
                String complay_peo=rs.getString("complay_peo");
                String complay_peo_call=rs.getString("complay_peo_call");
                String complay_address=rs.getString("complay_address");
                String complay_forget=rs.getString("complay_forget");
                String complay_code=rs.getString("complay_code");
                String complay_encode=rs.getString("complay_encode");
                String complay_sell=rs.getString("complay_sell");
                map=new HashMap<String, Object>();
                map.put("complay_id",complay_id);
                map.put("complay_name",complay_name);
                map.put("complay_peo",complay_peo);
                map.put("complay_peo_call",complay_peo_call);
                map.put("complay_address",complay_address);
                map.put("complay_forget",complay_forget);
                map.put("complay_code",complay_code);
                map.put("complay_encode",complay_encode);
                map.put("complay_sell",complay_sell);
                list.add(map);
            }

            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }
        return list;
    }
    public List<Map<String, Object>> SelectByCode(String Code){
        String sql="select * from complay where complay_code='"+Code+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String complay_id=rs.getString("complay_id");
                String complay_name=rs.getString("complay_name");
                String complay_peo=rs.getString("complay_peo");
                String complay_peo_call=rs.getString("complay_peo_call");
                String complay_address=rs.getString("complay_address");
                String complay_forget=rs.getString("complay_forget");
                String complay_code=rs.getString("complay_code");
                String complay_encode=rs.getString("complay_encode");
                String complay_sell=rs.getString("complay_sell");
                map=new HashMap<String, Object>();
                map.put("complay_id",complay_id);
                map.put("complay_name",complay_name);
                map.put("complay_peo",complay_peo);
                map.put("complay_peo_call",complay_peo_call);
                map.put("complay_address",complay_address);
                map.put("complay_forget",complay_forget);
                map.put("complay_code",complay_code);
                map.put("complay_encode",complay_encode);
                map.put("complay_sell",complay_sell);
                list.add(map);
            }



            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }
    public List<Map<String, Object>> SelectByencode(String encode){
        String sql="select * from complay where complay_encode='"+encode+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String complay_id=rs.getString("complay_id");
                String complay_name=rs.getString("complay_name");
                String complay_peo=rs.getString("complay_peo");
                String complay_peo_call=rs.getString("complay_peo_call");
                String complay_address=rs.getString("complay_address");
                String complay_forget=rs.getString("complay_forget");
                String complay_code=rs.getString("complay_code");
                String complay_encode=rs.getString("complay_encode");
                String complay_sell=rs.getString("complay_sell");
                map=new HashMap<String, Object>();
                map.put("complay_id",complay_id);
                map.put("complay_name",complay_name);
                map.put("complay_peo",complay_peo);
                map.put("complay_peo_call",complay_peo_call);
                map.put("complay_address",complay_address);
                map.put("complay_forget",complay_forget);
                map.put("complay_code",complay_code);
                map.put("complay_encode",complay_encode);
                map.put("complay_sell",complay_sell);
                list.add(map);
            }



            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }
    public List<Map<String, Object>> SelectAllif(String ID, String Code, String encode){
        String sql="select * from complay where complay_id='"+ID+"' and complay_Code='"+Code+"' and complay_encode='"+encode+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域

            while (rs.next()){
                String complay_id=rs.getString("complay_id");
                String complay_name=rs.getString("complay_name");
                String complay_peo=rs.getString("complay_peo");
                String complay_peo_call=rs.getString("complay_peo_call");
                String complay_address=rs.getString("complay_address");
                String complay_forget=rs.getString("complay_forget");
                String complay_code=rs.getString("complay_code");
                String complay_encode=rs.getString("complay_encode");
                String complay_sell=rs.getString("complay_sell");
                map=new HashMap<String, Object>();
                map.put("complay_id",complay_id);
                map.put("complay_name",complay_name);
                map.put("complay_peo",complay_peo);
                map.put("complay_peo_call",complay_peo_call);
                map.put("complay_address",complay_address);
                map.put("complay_forget",complay_forget);
                map.put("complay_code",complay_code);
                map.put("complay_encode",complay_encode);
                map.put("complay_sell",complay_sell);
                list.add(map);
            }


            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }


    public void DeleteByID(String ID){
        String sql="Delete from complay where complay_id='"+ID+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "数据以删除",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除数据失败，请检查信息",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println("DeleteById删除失败+"+e.toString());
        }
    }



    public int UpdateInfo(Map<String,String> map){
        int ok=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="update complay set complay_name='"+map.get("complay_name")+"',complay_peo='"+map.get("complay_peo")+"',complay_peo_call='"+map.get("complay_peo_call")+"',complay_address='"+map.get("complay_address")+"',complay_forget='"+map.get("complay_forget")+"',complay_code='"+map.get("complay_code")+"',complay_encode='"+map.get("complay_encode")+"',complay_sell='"+map.get("complay_sell")+"' where complay_id='"+map.get("complay_id")+"'";
        try {
            statement= connection.createStatement();
            ok=statement.executeUpdate(sql);


            connect.ConnectClose(statement, connection);
        }catch (Exception e){
            System.out.println(e.toString());
        }
        return ok;
    }


    public int count(){
        int count=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select count(*) from complay";
        try {
            statement= connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            while (rs.next()){
                count=Integer.parseInt(rs.getString("count(*)"));
            }
            connect.ConnectClose(statement,connection,rs);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return count;
    }
}
