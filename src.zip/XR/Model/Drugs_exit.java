package XR.Model;

import XR.Model.Connect.Connect;

import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Drugs_exit {

    //获取所有数据
    //所有数据
    public List<Map<String, Object>> SelectAllinfo() throws SQLException {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from drugs_exit";
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        while (rs.next()){
            String drugs_id=rs.getString("drugs_id");
            String drugs_name=rs.getString("drugs_name");
            String drugs_nums=rs.getString("drugs_nums");
            map=new HashMap<String, Object>();
            map.put("drugs_id",drugs_id);
            map.put("drugs_name",drugs_name);
            map.put("drugs_number",drugs_nums);
            list.add(map);
        }
        connect.ConnectClose(statement,connection,rs);
        return list;
    }


    //删除数据
    public void DeleteByID(String ID){
        String sql="Delete from drugs_exit where drugs_id='"+ID+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "数据以删除",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除数据失败，请检查信息",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println("DeleteById删除失败+"+e.toString());
        }
    }


    //添加数据
    public void Insert(String ID){
        Drugs drugs=new Drugs();
        Map<String, Object> map=drugs.selectInfo(ID);

        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement= connection.createStatement();
            String sql="INSERT INTO drugs_exit(drugs_id,drugs_name,drugs_nums) values('"+map.get("drugs_id")+"','"+map.get("drugs_name")+"','"+map.get("drugs_number")+"')";
            System.out.println(sql);
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "以设置该药品过期",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "联系管理员",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }
}
