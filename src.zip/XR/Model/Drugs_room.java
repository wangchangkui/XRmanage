package XR.Model;

import XR.Model.Connect.Connect;

import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Drugs_room {
    //所有数据
    public List<Map<String, Object>> SelectAllinfo() throws SQLException {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select * from drugs_room";
        //drugs_name	drugs_peo	drugs_pro_call	drugs_area	drugs_address	drugs_room_code	address_code	drugs_room_area_address
        statement=connection.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        while (rs.next()){
            String drugs_id=rs.getString("drugs_id");
            String drugs_name=rs.getString("drugs_name");
            String drugs_peo=rs.getString("drugs_peo");
            String drugs_pro_call=rs.getString("drugs_pro_call");
            String drugs_area=rs.getString("drugs_area");
            String drugs_address=rs.getString("drugs_address");
            String drugs_room_code=rs.getString("drugs_room_code");
            String address_code=rs.getString("address_code");
            String drugs_room_area_address=rs.getString("drugs_room_area_address");
            map=new HashMap<String, Object>();
            map.put("drugs_id",drugs_id);
            map.put("drugs_name",drugs_name);
            map.put("drugs_peo",drugs_peo);
            map.put("drugs_pro_call",drugs_pro_call);
            map.put("drugs_area",drugs_area);
            map.put("drugs_address",drugs_address);
            map.put("drugs_room_code",drugs_room_code);
            map.put("address_code",address_code);
            map.put("drugs_room_area_address",drugs_room_area_address);
            list.add(map);
        }
        connect.ConnectClose(statement,connection,rs);
        return list;
    }


    //drugs_name	drugs_peo	drugs_pro_call	drugs_area	drugs_address	drugs_room_code	 address_code	drugs_room_area_address

    public void insertDrugs_room(Map<String,Object> map){
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement= connection.createStatement();
            String sql="INSERT INTO drugs_room(drugs_id,drugs_name,drugs_peo,drugs_pro_call,drugs_area,drugs_address,drugs_room_code,address_code,drugs_room_area_address) values('"+map.get("drugs_id")+"','"+map.get("drugs_name")+"','"+map.get("drugs_peo")+"','"+map.get("drugs_pro_call")+"','"+map.get("drugs_area")+"','"+map.get("drugs_address")+"','"+map.get("drugs_room_code")+"','"+map.get("address_code")+"','"+map.get("drugs_room_area_address")+"')";

            System.out.println(sql);
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "添加数据成功",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "联系管理员",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }




    public List<Map<String, Object>> SelectByID(String ID){
        String sql="select * from drugs_room where drugs_id='"+ID+"'";
        System.out.println(sql);
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);
            //此处为数据待处理区域
            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_name=rs.getString("drugs_name");
                String drugs_peo=rs.getString("drugs_peo");
                String drugs_pro_call=rs.getString("drugs_pro_call");
                String drugs_area=rs.getString("drugs_area");
                String drugs_address=rs.getString("drugs_address");
                String drugs_room_code=rs.getString("drugs_room_code");
                String address_code=rs.getString("address_code");
                String drugs_room_area_address=rs.getString("drugs_room_area_address");
                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_name",drugs_name);
                map.put("drugs_peo",drugs_peo);
                map.put("drugs_pro_call",drugs_pro_call);
                map.put("drugs_area",drugs_area);
                map.put("drugs_address",drugs_address);
                map.put("drugs_room_code",drugs_room_code);
                map.put("address_code",address_code);
                map.put("drugs_room_area_address",drugs_room_area_address);
                list.add(map);
            }

            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }
        return list;
    }


    public List<Map<String, Object>> SelectByCode(String Code){
        String sql="select * from drugs_room where drugs_room_code='"+Code+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_name=rs.getString("drugs_name");
                String drugs_peo=rs.getString("drugs_peo");
                String drugs_pro_call=rs.getString("drugs_pro_call");
                String drugs_area=rs.getString("drugs_area");
                String drugs_address=rs.getString("drugs_address");
                String drugs_room_code=rs.getString("drugs_room_code");
                String address_code=rs.getString("address_code");
                String drugs_room_area_address=rs.getString("drugs_room_area_address");
                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_name",drugs_name);
                map.put("drugs_peo",drugs_peo);
                map.put("drugs_pro_call",drugs_pro_call);
                map.put("drugs_area",drugs_area);
                map.put("drugs_address",drugs_address);
                map.put("drugs_room_code",drugs_room_code);
                map.put("address_code",address_code);
                map.put("drugs_room_area_address",drugs_room_area_address);
                list.add(map);
            }



            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }


    public List<Map<String, Object>> select_class(String encode){
        String sql="select * from drugs_room where address_code='"+encode+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;
        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域
            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_name=rs.getString("drugs_name");
                String drugs_peo=rs.getString("drugs_peo");
                String drugs_pro_call=rs.getString("drugs_pro_call");
                String drugs_area=rs.getString("drugs_area");
                String drugs_address=rs.getString("drugs_address");
                String drugs_room_code=rs.getString("drugs_room_code");
                String address_code=rs.getString("address_code");
                String drugs_room_area_address=rs.getString("drugs_room_area_address");
                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_name",drugs_name);
                map.put("drugs_peo",drugs_peo);
                map.put("drugs_pro_call",drugs_pro_call);
                map.put("drugs_area",drugs_area);
                map.put("drugs_address",drugs_address);
                map.put("drugs_room_code",drugs_room_code);
                map.put("address_code",address_code);
                map.put("drugs_room_area_address",drugs_room_area_address);
                list.add(map);
            }

            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }


    public List<Map<String, Object>> SelectAllif(String ID, String Code, String drugs_classs){
        String sql="select * from drugs_room where drugs_id='"+ID+"' and drugs_room_code='"+Code+"' and address_code='"+drugs_classs+"'";
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=null;

        //相同部分 直接复制
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        ResultSet rs=null;
        try {
            statement= connection.createStatement();
            rs= statement.executeQuery(sql);

            //此处为数据待处理区域

            while (rs.next()){
                String drugs_id=rs.getString("drugs_id");
                String drugs_name=rs.getString("drugs_name");
                String drugs_peo=rs.getString("drugs_peo");
                String drugs_pro_call=rs.getString("drugs_pro_call");
                String drugs_area=rs.getString("drugs_area");
                String drugs_address=rs.getString("drugs_address");
                String drugs_room_code=rs.getString("drugs_room_code");
                String address_code=rs.getString("address_code");
                String drugs_room_area_address=rs.getString("drugs_room_area_address");
                map=new HashMap<String, Object>();
                map.put("drugs_id",drugs_id);
                map.put("drugs_name",drugs_name);
                map.put("drugs_peo",drugs_peo);
                map.put("drugs_pro_call",drugs_pro_call);
                map.put("drugs_area",drugs_area);
                map.put("drugs_address",drugs_address);
                map.put("drugs_room_code",drugs_room_code);
                map.put("address_code",address_code);
                map.put("drugs_room_area_address",drugs_room_area_address);
                list.add(map);
            }


            //关闭连接
            connect.ConnectClose(statement,connection,rs);
        }

        catch (Exception e){
            System.out.println(e.toString());
        }

        return list;
    }

    public void DeleteByID(String ID){
        String sql="Delete from drugs_room where drugs_id='"+ID+"'";
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        try {
            statement=connection.createStatement();
            int ok=statement.executeUpdate(sql);
            if(ok==1){
                JOptionPane.showMessageDialog(null,
                        "数据以删除",
                        "数据库信息",
                        INFORMATION_MESSAGE);
                connect.ConnectClose(statement,connection);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        "删除数据失败，请检查信息",
                        "数据库信息",
                        INFORMATION_MESSAGE);
            }
        }
        catch (Exception e){
            System.out.println("DeleteById删除失败+"+e.toString());
        }
    }


    //drugs_name	drugs_peo	drugs_pro_call	drugs_area	drugs_address	drugs_room_code	 address_code	drugs_room_area_address

    public int UpdateInfo(Map<String,String> map){
        int ok=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="update drugs_room set drugs_name='"+map.get("drugs_name")+"',drugs_peo='"+map.get("drugs_peo")+"',drugs_pro_call='"+map.get("drugs_pro_call")+"',drugs_area='"+map.get("drugs_area")+"',drugs_address='"+map.get("drugs_address")+"',drugs_room_code='"+map.get("drugs_room_code")+"',address_code='"+map.get("address_code")+"',drugs_room_area_address='"+map.get("drugs_room_area_address")+"' where drugs_id='"+map.get("drugs_id")+"'";
        try {
            statement= connection.createStatement();
            ok=statement.executeUpdate(sql);


            if(ok==1){
                System.out.println("更新成功");
            }
            connect.ConnectClose(statement, connection);
        }catch (Exception e){
            System.out.println(e.toString());
        }
        return ok;
    }

    public int count(){
        int count=0;
        Connect connect=new Connect();
        Connection connection=connect.ConnectSql();
        Statement statement=null;
        String sql="select count(*) from drugs_room";
        try {
            statement= connection.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            while (rs.next()){
                count=Integer.parseInt(rs.getString("count(*)"));
            }
            connect.ConnectClose(statement,connection,rs);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
        return count;
    }


}

